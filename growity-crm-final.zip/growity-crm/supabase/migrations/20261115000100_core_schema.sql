-- =============================================================================
-- Growity CRM · Phase 1 · Migration 1: core schema
-- Tables: profiles, verticals, user_verticals, app_settings
-- =============================================================================

-- Private schema for helper functions. It is NOT exposed through the Supabase
-- Data API (only "public" is exposed by default), so ordinary users cannot call
-- these functions as RPCs. RLS policies can still use them.
create schema if not exists app_private;

-- -----------------------------------------------------------------------------
-- Shared trigger: keep updated_at current
-- -----------------------------------------------------------------------------
create or replace function app_private.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

-- -----------------------------------------------------------------------------
-- TABLE 1: profiles
-- -----------------------------------------------------------------------------
create table public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  full_name   text not null check (char_length(trim(full_name)) between 1 and 120),
  email       text not null check (position('@' in email) > 1),
  phone       text check (phone is null or char_length(phone) <= 20),
  role        text not null default 'salesperson'
              check (role in ('admin', 'cxo', 'manager', 'salesperson')),
  manager_id  uuid references public.profiles (id) on delete set null,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  constraint profiles_manager_not_self check (manager_id is null or manager_id <> id)
);

comment on table public.profiles is 'Application users. One row per auth.users row.';

-- Email unique, case-insensitive
create unique index profiles_email_unique_idx on public.profiles (lower(email));
create index profiles_manager_id_idx on public.profiles (manager_id);
create index profiles_role_idx on public.profiles (role);

create trigger profiles_set_updated_at
  before update on public.profiles
  for each row execute function app_private.set_updated_at();

-- -----------------------------------------------------------------------------
-- TABLE 2: verticals
-- -----------------------------------------------------------------------------
create table public.verticals (
  id          uuid primary key default gen_random_uuid(),
  code        text not null unique check (code ~ '^[A-Z]{2,10}$'),
  name        text not null check (char_length(trim(name)) between 1 and 120),
  description text,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now()
);

comment on table public.verticals is 'Business verticals (AGY, SCL, ACD). Every future lead/customer/opportunity references one.';

-- -----------------------------------------------------------------------------
-- TABLE 3: user_verticals
-- -----------------------------------------------------------------------------
create table public.user_verticals (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles (id) on delete cascade,
  vertical_id uuid not null references public.verticals (id) on delete cascade,
  created_at  timestamptz not null default now(),
  constraint user_verticals_user_vertical_unique unique (user_id, vertical_id)
);

-- (user_id, vertical_id) unique index already covers lookups by user_id
create index user_verticals_vertical_id_idx on public.user_verticals (vertical_id);

-- -----------------------------------------------------------------------------
-- TABLE 4: app_settings
-- -----------------------------------------------------------------------------
create table public.app_settings (
  id            uuid primary key default gen_random_uuid(),
  setting_key   text not null unique check (setting_key ~ '^[a-z][a-z0-9_]{1,63}$'),
  setting_value jsonb not null,
  updated_at    timestamptz not null default now()
);

create trigger app_settings_set_updated_at
  before update on public.app_settings
  for each row execute function app_private.set_updated_at();
