-- =============================================================================
-- Growity CRM · Phase 1 · Migration 4: guard triggers + user provisioning
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. Profile creation from auth.users
--
-- Role is NEVER read from user-supplied metadata: every new profile starts as
-- 'salesperson'. The admin then sets the role through the RLS-protected admin
-- screen.
--
-- A profile is only ACTIVE when the account was provisioned server-side by an
-- admin, which is marked in raw_app_meta_data.provisioned = true. Only the
-- service-role key can write app_metadata, so a self-signup (should public
-- sign-ups ever be switched on by mistake) produces an inactive profile with
-- no access.
-- -----------------------------------------------------------------------------
create or replace function app_private.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_full_name text;
begin
  v_full_name := nullif(trim(coalesce(new.raw_user_meta_data ->> 'full_name', '')), '');

  insert into public.profiles (id, full_name, email, phone, role, is_active)
  values (
    new.id,
    coalesce(v_full_name, split_part(new.email, '@', 1)),
    lower(new.email),
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'phone', '')), ''),
    'salesperson',
    coalesce((new.raw_app_meta_data ->> 'provisioned')::boolean, false)
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function app_private.handle_new_auth_user();

-- Keep profiles.email in sync with auth (auth is the source of truth)
create or replace function app_private.handle_auth_user_email_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.email is distinct from old.email then
    update public.profiles set email = lower(new.email) where id = new.id;
  end if;
  return new;
end;
$$;

drop trigger if exists on_auth_user_email_changed on auth.users;
create trigger on_auth_user_email_changed
  after update of email on auth.users
  for each row execute function app_private.handle_auth_user_email_change();

-- -----------------------------------------------------------------------------
-- 2. Profile update guard
--
-- RLS decides WHICH rows a user may update; this trigger decides WHICH COLUMNS.
--   * non-admins: may change only full_name and phone on their own row
--     (so nobody can make themselves admin/cxo, change manager, or reactivate)
--   * admins: cannot demote or deactivate themselves, and the last active
--     admin can never be removed (prevents lock-out)
--   * manager_id must point to an active manager/cxo/admin, with no cycles
-- Server-side contexts with no JWT (migrations, service role) are trusted.
-- -----------------------------------------------------------------------------
create or replace function app_private.guard_profile_update()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_is_admin boolean := app_private.is_admin();
  v_manager_role text;
  v_cursor uuid;
  v_depth int := 0;
begin
  if new.id is distinct from old.id then
    raise exception 'Profile id cannot be changed' using errcode = '42501';
  end if;

  -- Column-level rules for signed-in users
  if v_uid is not null then
    if not v_is_admin then
      if new.role is distinct from old.role
         or new.manager_id is distinct from old.manager_id
         or new.is_active is distinct from old.is_active
         or new.email is distinct from old.email
         or new.created_at is distinct from old.created_at then
        raise exception 'Only an admin can change role, manager, status or email'
          using errcode = '42501';
      end if;
    else
      if old.id = v_uid and (new.role <> 'admin' or not new.is_active) then
        raise exception 'Admins cannot remove their own admin role or deactivate themselves'
          using errcode = '42501';
      end if;
    end if;
  end if;

  -- Never leave the system without an active admin
  if old.role = 'admin' and old.is_active and (new.role <> 'admin' or not new.is_active) then
    if not exists (
      select 1 from public.profiles p
      where p.role = 'admin' and p.is_active and p.id <> old.id
    ) then
      raise exception 'At least one active admin is required' using errcode = '23514';
    end if;
  end if;

  -- Manager validation
  if new.manager_id is not null and new.manager_id is distinct from old.manager_id then
    select p.role into v_manager_role
    from public.profiles p
    where p.id = new.manager_id and p.is_active;

    if v_manager_role is null or v_manager_role not in ('manager', 'cxo', 'admin') then
      raise exception 'Manager must be an active manager, CXO or admin' using errcode = '23514';
    end if;

    -- Walk up the chain to make sure we are not creating a loop
    v_cursor := new.manager_id;
    while v_cursor is not null and v_depth < 20 loop
      if v_cursor = new.id then
        raise exception 'Manager assignment would create a reporting loop' using errcode = '23514';
      end if;
      select p.manager_id into v_cursor from public.profiles p where p.id = v_cursor;
      v_depth := v_depth + 1;
    end loop;
  end if;

  return new;
end;
$$;

create trigger profiles_guard_update
  before update on public.profiles
  for each row execute function app_private.guard_profile_update();

-- -----------------------------------------------------------------------------
-- 3. Admin-only RPC for the users screen: returns users with their verticals
--    and manager name in one query (avoids N+1 requests from the app).
--    Exposed in public on purpose, but it re-checks admin and returns nothing
--    to anyone else.
-- -----------------------------------------------------------------------------
create or replace function public.admin_list_users(
  p_search text default null,
  p_role text default null,
  p_vertical_code text default null
)
returns table (
  id uuid,
  full_name text,
  email text,
  phone text,
  role text,
  is_active boolean,
  created_at timestamptz,
  manager_id uuid,
  manager_name text,
  vertical_codes text[]
)
language sql
stable
security definer
set search_path = ''
as $$
  select
    p.id, p.full_name, p.email, p.phone, p.role, p.is_active, p.created_at,
    p.manager_id, m.full_name as manager_name,
    coalesce(
      array_agg(v.code order by v.code) filter (where v.code is not null),
      '{}'::text[]
    ) as vertical_codes
  from public.profiles p
  left join public.profiles m on m.id = p.manager_id
  left join public.user_verticals uv on uv.user_id = p.id
  left join public.verticals v on v.id = uv.vertical_id
  where app_private.is_admin()
    and (
      p_search is null or p_search = ''
      or p.full_name ilike '%' || p_search || '%'
      or p.email ilike '%' || p_search || '%'
      or coalesce(p.phone, '') ilike '%' || p_search || '%'
    )
    and (p_role is null or p_role = '' or p.role = p_role)
    and (
      p_vertical_code is null or p_vertical_code = ''
      or exists (
        select 1 from public.user_verticals uv2
        join public.verticals v2 on v2.id = uv2.vertical_id
        where uv2.user_id = p.id and v2.code = p_vertical_code
      )
    )
  group by p.id, m.full_name
  order by p.created_at desc
$$;

revoke all on function public.admin_list_users(text, text, text) from public, anon;
grant execute on function public.admin_list_users(text, text, text) to authenticated;

-- Atomically replace a user's vertical assignments (admin only)
create or replace function public.admin_set_user_verticals(p_user_id uuid, p_vertical_ids uuid[])
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not app_private.is_admin() then
    raise exception 'Only admins can assign verticals' using errcode = '42501';
  end if;

  if not exists (select 1 from public.profiles where id = p_user_id) then
    raise exception 'User not found' using errcode = 'P0002';
  end if;

  delete from public.user_verticals
  where user_id = p_user_id
    and not (vertical_id = any (coalesce(p_vertical_ids, '{}')));

  insert into public.user_verticals (user_id, vertical_id)
  select p_user_id, v.id
  from public.verticals v
  where v.id = any (coalesce(p_vertical_ids, '{}'))
  on conflict (user_id, vertical_id) do nothing;
end;
$$;

revoke all on function public.admin_set_user_verticals(uuid, uuid[]) from public, anon;
grant execute on function public.admin_set_user_verticals(uuid, uuid[]) to authenticated;

-- Trigger functions must not be callable directly
revoke execute on function app_private.handle_new_auth_user() from authenticated;
revoke execute on function app_private.handle_auth_user_email_change() from authenticated;
revoke execute on function app_private.set_updated_at() from authenticated;
revoke execute on function app_private.guard_profile_update() from authenticated;
