-- =============================================================================
-- Growity CRM · Phase 1 · Migration 3: Row Level Security
-- RLS is enabled on every application table.
-- Policies call (select app_private.fn()) so Postgres evaluates the helper once
-- per statement rather than once per row.
-- =============================================================================

alter table public.profiles       enable row level security;
alter table public.verticals      enable row level security;
alter table public.user_verticals enable row level security;
alter table public.app_settings   enable row level security;


-- -----------------------------------------------------------------------------
-- Table privileges (defence in depth on top of RLS)
--   anon          : nothing
--   authenticated : only the verbs that have a policy below
-- -----------------------------------------------------------------------------
revoke all on public.profiles, public.verticals, public.user_verticals, public.app_settings from anon;
revoke all on public.profiles, public.verticals, public.user_verticals, public.app_settings from authenticated;

grant select, update                 on public.profiles       to authenticated; -- inserts come from the auth trigger only
grant select, insert, update, delete on public.verticals      to authenticated;
grant select, insert, delete         on public.user_verticals to authenticated;
grant select, insert, update         on public.app_settings   to authenticated;

grant all on public.profiles, public.verticals, public.user_verticals, public.app_settings to service_role;

-- =============================================================================
-- profiles
-- =============================================================================
-- Who can see a profile:
--   * yourself
--   * admin / cxo: everyone
--   * manager: their whole reporting tree
--   * anyone: their own manager (to show "Reports to")
create policy profiles_select on public.profiles
  for select to authenticated
  using (
    (select app_private.is_active_user()) and (
      id = (select auth.uid())
      or (select app_private.has_global_access())
      or (select app_private.is_team_member(id))
      or id = (select app_private.current_manager_id())
    )
  );

-- Admin may update anyone. Everyone else may update only their own row, and the
-- guard trigger below limits them to full_name and phone.
create policy profiles_update on public.profiles
  for update to authenticated
  using (
    (select app_private.is_admin())
    or (id = (select auth.uid()) and (select app_private.is_active_user()))
  )
  with check (
    (select app_private.is_admin())
    or id = (select auth.uid())
  );

-- No INSERT / DELETE policies: profiles are created by the auth.users trigger
-- and are deactivated rather than deleted.

-- =============================================================================
-- verticals
-- =============================================================================
create policy verticals_select on public.verticals
  for select to authenticated
  using ((select app_private.has_vertical_access(id)));

create policy verticals_insert on public.verticals
  for insert to authenticated
  with check ((select app_private.is_admin()));

create policy verticals_update on public.verticals
  for update to authenticated
  using ((select app_private.is_admin()))
  with check ((select app_private.is_admin()));

create policy verticals_delete on public.verticals
  for delete to authenticated
  using ((select app_private.is_admin()));

-- =============================================================================
-- user_verticals
-- =============================================================================
create policy user_verticals_select on public.user_verticals
  for select to authenticated
  using (
    (select app_private.is_active_user()) and (
      user_id = (select auth.uid())
      or (select app_private.has_global_access())
      or (select app_private.is_team_member(user_id))
    )
  );

create policy user_verticals_insert on public.user_verticals
  for insert to authenticated
  with check ((select app_private.is_admin()));

create policy user_verticals_delete on public.user_verticals
  for delete to authenticated
  using ((select app_private.is_admin()));

-- =============================================================================
-- app_settings
-- =============================================================================
create policy app_settings_select on public.app_settings
  for select to authenticated
  using ((select app_private.is_active_user()));

create policy app_settings_insert on public.app_settings
  for insert to authenticated
  with check ((select app_private.is_admin()));

create policy app_settings_update on public.app_settings
  for update to authenticated
  using ((select app_private.is_admin()))
  with check ((select app_private.is_admin()));
