-- =============================================================================
-- Growity CRM · Phase 1 · Migration 5: reference data
-- Kept in a migration (not only seed.sql) so production gets it too.
-- Idempotent: safe to re-run.
-- =============================================================================

insert into public.verticals (code, name, description) values
  ('AGY', 'Growity Agency',  null),
  ('SCL', 'Scaler',          null),
  ('ACD', 'Growity Academy', null)
on conflict (code) do nothing;

insert into public.app_settings (setting_key, setting_value) values
  ('company_name',            '"Growity Solutions"'::jsonb),
  ('currency',                '"INR"'::jsonb),
  ('timezone',                '"Asia/Kolkata"'::jsonb),
  ('fiscal_year_start_month', '4'::jsonb)
on conflict (setting_key) do nothing;
