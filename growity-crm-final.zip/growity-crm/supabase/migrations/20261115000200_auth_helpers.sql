-- =============================================================================
-- Growity CRM · Phase 1 · Migration 2: authorization helper functions
--
-- All helpers are SECURITY DEFINER so they read profiles / user_verticals
-- without re-entering RLS. That is what prevents the classic "infinite
-- recursion detected in policy" problem when a profiles policy needs to know
-- the caller's role or manager relationships.
--
-- Rules every helper follows:
--   * identity always comes from auth.uid() (the verified JWT), never from a
--     parameter the client controls
--   * an inactive or missing profile has NO role and NO access
--   * search_path is pinned to '' and every object is schema-qualified
--   * they live in app_private, which is not exposed via the Data API
-- =============================================================================

-- Role of the signed-in user, or NULL if not signed in / no profile / inactive
create or replace function app_private.current_user_role()
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select p.role
  from public.profiles p
  where p.id = auth.uid()
    and p.is_active
$$;

-- The caller's own manager (used so everyone can see who they report to)
create or replace function app_private.current_manager_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $$
  select p.manager_id
  from public.profiles p
  where p.id = auth.uid()
    and p.is_active
$$;

create or replace function app_private.is_active_user()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select app_private.current_user_role() is not null
$$;

create or replace function app_private.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(app_private.current_user_role() = 'admin', false)
$$;

-- Admin and CXO see every vertical and all business data
create or replace function app_private.has_global_access()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(app_private.current_user_role() in ('admin', 'cxo'), false)
$$;

-- IDs of everyone who reports to the caller, directly or indirectly.
-- Recursive CTE runs inside SECURITY DEFINER, so no RLS recursion.
-- Depth is capped to guard against bad data.
create or replace function app_private.team_member_ids()
returns setof uuid
language sql
stable
security definer
set search_path = ''
as $$
  with recursive team as (
    select p.id, 1 as depth
    from public.profiles p
    where p.manager_id = auth.uid()
      and app_private.current_user_role() = 'manager'
    union all
    select p.id, t.depth + 1
    from public.profiles p
    join team t on p.manager_id = t.id
    where t.depth < 10
  )
  select distinct id from team
$$;

create or replace function app_private.is_team_member(target_user_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from app_private.team_member_ids() t where t = target_user_id
  )
$$;

-- Vertical IDs the caller may work in
create or replace function app_private.accessible_vertical_ids()
returns setof uuid
language sql
stable
security definer
set search_path = ''
as $$
  select v.id
  from public.verticals v
  where app_private.has_global_access()
  union
  select uv.vertical_id
  from public.user_verticals uv
  where uv.user_id = auth.uid()
    and app_private.is_active_user()
$$;

create or replace function app_private.has_vertical_access(target_vertical_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from app_private.accessible_vertical_ids() v where v = target_vertical_id
  )
$$;

-- -----------------------------------------------------------------------------
-- PERMISSION FOUNDATION FOR FUTURE BUSINESS TABLES (leads, customers, ...)
--
-- Every future business record will carry owner_id + vertical_id. Its RLS
-- policies should call these two functions instead of re-implementing rules:
--
--   create policy "leads_select" on public.leads for select to authenticated
--     using ((select app_private.can_view_record(owner_id, vertical_id)));
--
--   ADMIN / CXO : everything
--   MANAGER     : records in assigned verticals owned by self or team
--   SALESPERSON : own records in assigned verticals
-- -----------------------------------------------------------------------------
create or replace function app_private.can_view_record(record_owner_id uuid, record_vertical_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select case app_private.current_user_role()
    when 'admin' then true
    when 'cxo' then true
    when 'manager' then
      app_private.has_vertical_access(record_vertical_id)
      and (record_owner_id = auth.uid() or app_private.is_team_member(record_owner_id))
    when 'salesperson' then
      app_private.has_vertical_access(record_vertical_id)
      and record_owner_id = auth.uid()
    else false
  end
$$;

-- CXO is a viewing role for business data ("access business records");
-- writes are for admin, managers (own + team) and salespeople (own).
create or replace function app_private.can_manage_record(record_owner_id uuid, record_vertical_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select case app_private.current_user_role()
    when 'admin' then true
    when 'manager' then
      app_private.has_vertical_access(record_vertical_id)
      and (record_owner_id = auth.uid() or app_private.is_team_member(record_owner_id))
    when 'salesperson' then
      app_private.has_vertical_access(record_vertical_id)
      and record_owner_id = auth.uid()
    else false
  end
$$;

-- -----------------------------------------------------------------------------
-- Privileges: nobody but authenticated may run helpers; anon gets nothing.
-- -----------------------------------------------------------------------------
revoke all on schema app_private from public, anon;
grant usage on schema app_private to authenticated, service_role;

revoke all on all functions in schema app_private from public, anon;
grant execute on all functions in schema app_private to authenticated, service_role;

alter default privileges in schema app_private revoke execute on functions from public, anon;
