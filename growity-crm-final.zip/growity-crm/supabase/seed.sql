-- Local development seed (run automatically by `supabase db reset`).
-- Reference data lives in migrations/20261115000500_seed_reference_data.sql so
-- every environment gets it; this file only repeats it idempotently.
-- No fake users or business data are created here.

insert into public.verticals (code, name, description) values
  ('AGY', 'Growity Agency',  null),
  ('SCL', 'Scaler',          null),
  ('ACD', 'Growity Academy', null)
on conflict (code) do nothing;

insert into public.app_settings (setting_key, setting_value) values
  ('company_name',            '"Growity Solutions"'::jsonb),
  ('currency',                '"INR"'::jsonb),
  ('timezone',                '"Asia/Kolkata"'::jsonb),
  ('fiscal_year_start_month', '4'::jsonb)
on conflict (setting_key) do nothing;
