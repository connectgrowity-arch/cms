-- =============================================================================
-- Growity CRM · Phase 1 · RLS & permission test suite
--
-- Runs inside one transaction and ROLLS BACK, so it leaves no data behind.
-- Works on the local shim (tests/local/run-local.sh) and on a real Supabase
-- database via psql:
--   psql "$SUPABASE_DB_URL" -v ON_ERROR_STOP=1 -f supabase/tests/rls_policies.test.sql
-- Any failed check aborts with "TEST FAILED: ...".
-- =============================================================================
\set ON_ERROR_STOP 1
set client_min_messages = warning;
begin;

-- ---------------------------------------------------------------- fixtures --
-- Fixed IDs so the role switches below are readable
\set admin   '''00000000-0000-0000-0000-0000000000a1'''
\set admin2  '''00000000-0000-0000-0000-0000000000a2'''
\set cxo     '''00000000-0000-0000-0000-0000000000c1'''
\set mgr     '''00000000-0000-0000-0000-0000000000b1'''
\set s1      '''00000000-0000-0000-0000-0000000000d1'''
\set s2      '''00000000-0000-0000-0000-0000000000d2'''
\set inact   '''00000000-0000-0000-0000-0000000000e1'''
\set selfreg '''00000000-0000-0000-0000-0000000000f1'''

-- Provisioned accounts (admin-created → app_metadata.provisioned = true).
-- s1 tries to smuggle role=admin through user metadata: must be ignored.
insert into auth.users (id, email, raw_user_meta_data, raw_app_meta_data) values
  (:admin,  'admin@test.growity',  '{"full_name":"Test Admin"}',  '{"provisioned":true}'),
  (:admin2, 'admin2@test.growity', '{"full_name":"Test Admin 2"}','{"provisioned":true}'),
  (:cxo,    'cxo@test.growity',    '{"full_name":"Test CXO"}',    '{"provisioned":true}'),
  (:mgr,    'mgr@test.growity',    '{"full_name":"Test Manager"}','{"provisioned":true}'),
  (:s1,     's1@test.growity',     '{"full_name":"Sales One","role":"admin"}', '{"provisioned":true}'),
  (:s2,     's2@test.growity',     '{"full_name":"Sales Two"}',   '{"provisioned":true}'),
  (:inact,  'inactive@test.growity','{"full_name":"Inactive"}',   '{"provisioned":true}');
-- A self-signup (no provisioned flag)
insert into auth.users (id, email, raw_user_meta_data) values
  (:selfreg, 'selfsignup@test.growity', '{"full_name":"Self Signup","role":"admin"}');

do $$ begin
  assert (select role from public.profiles where email = 's1@test.growity') = 'salesperson',
    'TEST FAILED: role from user metadata must be ignored on signup';
  assert (select is_active from public.profiles where email = 's1@test.growity'),
    'TEST FAILED: provisioned user should be active';
  assert not (select is_active from public.profiles where email = 'selfsignup@test.growity'),
    'TEST FAILED: self-signup must start inactive';
  assert (select role from public.profiles where email = 'selfsignup@test.growity') = 'salesperson',
    'TEST FAILED: self-signup role must be salesperson';
end $$;

-- Roles, reporting lines and vertical assignments (set as trusted backend)
update public.profiles set role = 'admin'   where email in ('admin@test.growity','admin2@test.growity');
update public.profiles set role = 'cxo'     where email = 'cxo@test.growity';
update public.profiles set role = 'manager' where email = 'mgr@test.growity';
update public.profiles set manager_id = :mgr where email = 's1@test.growity';
update public.profiles set is_active = false where email = 'inactive@test.growity';

insert into public.user_verticals (user_id, vertical_id)
select :mgr::uuid, id from public.verticals where code = 'AGY' union all
select :s1::uuid,  id from public.verticals where code = 'AGY' union all
select :s2::uuid,  id from public.verticals where code = 'SCL' union all
select :inact::uuid, id from public.verticals where code = 'AGY';

-- psql helpers to switch identity
\set as_anon 'reset role; set local request.jwt.claims = ''''; set local role anon;'
\set as_admin 'reset role; set local request.jwt.claims = ''{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}''; set local role authenticated;'
\set as_cxo   'reset role; set local request.jwt.claims = ''{"sub":"00000000-0000-0000-0000-0000000000c1","role":"authenticated"}''; set local role authenticated;'
\set as_mgr   'reset role; set local request.jwt.claims = ''{"sub":"00000000-0000-0000-0000-0000000000b1","role":"authenticated"}''; set local role authenticated;'
\set as_s1    'reset role; set local request.jwt.claims = ''{"sub":"00000000-0000-0000-0000-0000000000d1","role":"authenticated"}''; set local role authenticated;'
\set as_s2    'reset role; set local request.jwt.claims = ''{"sub":"00000000-0000-0000-0000-0000000000d2","role":"authenticated"}''; set local role authenticated;'
\set as_inact 'reset role; set local request.jwt.claims = ''{"sub":"00000000-0000-0000-0000-0000000000e1","role":"authenticated"}''; set local role authenticated;'
\set as_backend 'reset role; set local request.jwt.claims = '''';'

-- ======================================================== 1. anonymous ====
:as_anon
do $$ begin
  begin
    perform 1 from public.profiles;
    raise exception 'TEST FAILED: anon can read profiles';
  exception when insufficient_privilege then null; end;
  begin
    perform 1 from public.app_settings;
    raise exception 'TEST FAILED: anon can read app_settings';
  exception when insufficient_privilege then null; end;
  begin
    perform app_private.is_admin();
    raise exception 'TEST FAILED: anon can call internal helpers';
  exception when insufficient_privilege then null; end;
  begin
    perform * from public.admin_list_users();
    raise exception 'TEST FAILED: anon can call admin_list_users';
  exception when insufficient_privilege then null; end;
end $$;

-- ================================================== 2. profile visibility ==
:as_s1
do $$ begin
  assert (select count(*) from public.profiles) = 2,
    'TEST FAILED: salesperson should see self + own manager only';
  assert exists (select 1 from public.profiles where email = 'mgr@test.growity'),
    'TEST FAILED: salesperson should see own manager';
  assert not exists (select 1 from public.profiles where email = 's2@test.growity'),
    'TEST FAILED: salesperson must not see other salespeople';
end $$;

:as_s2
do $$ begin
  assert (select count(*) from public.profiles) = 1, 'TEST FAILED: s2 should see only self';
end $$;

:as_mgr
do $$ begin
  assert (select count(*) from public.profiles) = 2, 'TEST FAILED: manager should see self + team';
  assert exists (select 1 from public.profiles where email = 's1@test.growity'),
    'TEST FAILED: manager should see direct report';
  assert not exists (select 1 from public.profiles where email = 's2@test.growity'),
    'TEST FAILED: manager must not see users outside the team';
end $$;

:as_cxo
do $$ begin
  assert (select count(*) from public.profiles) = 8, 'TEST FAILED: cxo should see all profiles';
end $$;

:as_admin
do $$ begin
  assert (select count(*) from public.profiles) = 8, 'TEST FAILED: admin should see all profiles';
end $$;

:as_inact
do $$ begin
  assert (select count(*) from public.profiles) = 0, 'TEST FAILED: inactive user must see nothing';
  assert app_private.current_user_role() is null, 'TEST FAILED: inactive user must have no role';
end $$;

-- ================================================== 3. vertical visibility ==
:as_s1
do $$ begin
  assert (select array_agg(code) from public.verticals) = array['AGY'],
    'TEST FAILED: s1 should see only AGY';
end $$;
:as_s2
do $$ begin
  assert (select array_agg(code) from public.verticals) = array['SCL'],
    'TEST FAILED: s2 should see only SCL';
end $$;
:as_mgr
do $$ begin
  assert (select count(*) from public.verticals) = 1, 'TEST FAILED: manager sees assigned verticals only';
end $$;
:as_cxo
do $$ begin
  assert (select count(*) from public.verticals) = 3, 'TEST FAILED: cxo should see all verticals';
end $$;
:as_inact
do $$ begin
  assert (select count(*) from public.verticals) = 0, 'TEST FAILED: inactive user sees no verticals';
end $$;

-- ===================================== 4. self-escalation & column guards ==
:as_s1
do $$ begin
  begin
    update public.profiles set role = 'admin' where id = auth.uid();
    raise exception 'TEST FAILED: salesperson promoted self to admin';
  exception when insufficient_privilege then null; end;
  begin
    update public.profiles set role = 'cxo' where id = auth.uid();
    raise exception 'TEST FAILED: salesperson promoted self to cxo';
  exception when insufficient_privilege then null; end;
  begin
    update public.profiles set manager_id = null where id = auth.uid();
    raise exception 'TEST FAILED: salesperson changed own manager';
  exception when insufficient_privilege then null; end;
  begin
    insert into public.profiles (id, full_name, email, role)
    values (gen_random_uuid(), 'x', 'x@x.x', 'admin');
    raise exception 'TEST FAILED: user inserted a profile';
  exception when insufficient_privilege then null; end;
  begin
    delete from public.profiles where id = auth.uid();
    raise exception 'TEST FAILED: user deleted a profile';
  exception when insufficient_privilege then null; end;
end $$;

-- allowed: own name and phone
update public.profiles set full_name = 'Sales One Renamed', phone = '+91 90000 00000'
where id = auth.uid();
do $$ begin
  assert (select full_name from public.profiles where id = auth.uid()) = 'Sales One Renamed',
    'TEST FAILED: user could not edit own name';
end $$;

-- other users' rows are untouchable (0 rows affected, no error)
do $$ declare n int; begin
  update public.profiles set full_name = 'hacked' where email = 'mgr@test.growity';
  get diagnostics n = row_count;
  assert n = 0, 'TEST FAILED: salesperson edited another profile';
end $$;

:as_mgr
do $$ declare n int; begin
  update public.profiles set role = 'manager' where email = 's1@test.growity';
  get diagnostics n = row_count;
  assert n = 0, 'TEST FAILED: manager changed a team member role';
end $$;

:as_cxo
do $$ declare n int; begin
  update public.profiles set is_active = false where email = 's2@test.growity';
  get diagnostics n = row_count;
  assert n = 0, 'TEST FAILED: cxo administered users';
  begin
    update public.profiles set role = 'admin' where id = auth.uid();
    raise exception 'TEST FAILED: cxo promoted self to admin';
  exception when insufficient_privilege then null; end;
end $$;

-- ================================================= 5. vertical assignment ==
:as_s1
do $$ begin
  begin
    insert into public.user_verticals (user_id, vertical_id)
    select auth.uid(), id from public.verticals where code = 'AGY';
    raise exception 'TEST FAILED: salesperson assigned a vertical';
  exception when insufficient_privilege then null; end;
  begin
    perform public.admin_set_user_verticals(auth.uid(), array[]::uuid[]);
    raise exception 'TEST FAILED: salesperson used admin_set_user_verticals';
  exception when insufficient_privilege then null; end;
  assert (select count(*) from public.user_verticals) = 1,
    'TEST FAILED: salesperson should see only own assignment';
  assert (select count(*) from public.admin_list_users()) = 0,
    'TEST FAILED: admin_list_users leaked rows to salesperson';
end $$;

:as_mgr
do $$ begin
  assert (select count(*) from public.user_verticals) = 2,
    'TEST FAILED: manager should see own + team assignments';
  begin
    perform public.admin_set_user_verticals('00000000-0000-0000-0000-0000000000d1', array[]::uuid[]);
    raise exception 'TEST FAILED: manager used admin_set_user_verticals';
  exception when insufficient_privilege then null; end;
end $$;

:as_admin
do $$ begin
  perform public.admin_set_user_verticals(
    '00000000-0000-0000-0000-0000000000d2',
    array(select id from public.verticals where code in ('SCL','ACD'))
  );
  assert (select count(*) from public.user_verticals
          where user_id = '00000000-0000-0000-0000-0000000000d2') = 2,
    'TEST FAILED: admin could not assign verticals';
  assert (select count(*) from public.admin_list_users()) = 8,
    'TEST FAILED: admin_list_users should return all users';
  assert (select count(*) from public.admin_list_users(null, 'salesperson', null)) = 4,
    'TEST FAILED: role filter';
  assert (select count(*) from public.admin_list_users(null, null, 'ACD')) = 1,
    'TEST FAILED: vertical filter';
  assert (select count(*) from public.admin_list_users('sales two', null, null)) = 1,
    'TEST FAILED: search';
end $$;
:as_s2
do $$ begin
  assert (select count(*) from public.verticals) = 2, 'TEST FAILED: new assignment not visible to user';
end $$;

-- ===================================================== 6. app settings ====
:as_s1
do $$ declare n int; begin
  assert (select count(*) from public.app_settings) = 4, 'TEST FAILED: users should read settings';
  update public.app_settings set setting_value = '"USD"' where setting_key = 'currency';
  get diagnostics n = row_count;
  assert n = 0, 'TEST FAILED: salesperson changed settings';
  begin
    insert into public.app_settings (setting_key, setting_value) values ('evil', '1');
    raise exception 'TEST FAILED: salesperson inserted a setting';
  exception when insufficient_privilege then null; end;
end $$;
:as_inact
do $$ begin
  assert (select count(*) from public.app_settings) = 0, 'TEST FAILED: inactive user read settings';
end $$;
:as_admin
update public.app_settings set setting_value = '"Growity Solutions"' where setting_key = 'company_name';

-- ================================================ 7. admin safety rails ====
:as_admin
do $$ begin
  begin
    update public.profiles set is_active = false where id = auth.uid();
    raise exception 'TEST FAILED: admin deactivated self';
  exception when insufficient_privilege then null; end;
  begin
    update public.profiles set role = 'cxo' where id = auth.uid();
    raise exception 'TEST FAILED: admin demoted self';
  exception when insufficient_privilege then null; end;
  begin
    update public.profiles set manager_id = '00000000-0000-0000-0000-0000000000d2'
    where email = 's1@test.growity';
    raise exception 'TEST FAILED: salesperson accepted as manager';
  exception when check_violation then null; end;
  begin
    update public.profiles set manager_id = '00000000-0000-0000-0000-0000000000d1'
    where email = 'mgr@test.growity';
    raise exception 'TEST FAILED: manager loop allowed';
  exception when check_violation then null; end;
end $$;

-- admin deactivates s2 → s2 immediately loses all access
update public.profiles set is_active = false where email = 's2@test.growity';
:as_s2
do $$ begin
  assert (select count(*) from public.profiles) = 0, 'TEST FAILED: deactivated user still sees data';
  assert (select count(*) from public.verticals) = 0, 'TEST FAILED: deactivated user still sees verticals';
end $$;

-- last active admin cannot be removed, even by the backend
:as_backend
update public.profiles set is_active = false where email = 'admin2@test.growity';
do $$ begin
  -- Only meaningful when no other real admin exists in this database
  if not exists (select 1 from public.profiles
                 where role = 'admin' and is_active and email <> 'admin@test.growity') then
    begin
      update public.profiles set role = 'manager' where email = 'admin@test.growity';
      raise exception 'TEST FAILED: last active admin was removed';
    exception when check_violation then null; end;
  end if;
end $$;

-- ============================ 8. permission foundation for future tables ===
-- can_view_record / can_manage_record(owner_id, vertical_id)

:as_s1
do $$ declare agy uuid; scl uuid; begin
  select id into agy from public.verticals where code = 'AGY';
  select id into scl from public.verticals where code = 'SCL';
  assert app_private.can_view_record(auth.uid(), agy), 'TEST FAILED: s1 own AGY record';
  assert app_private.can_manage_record(auth.uid(), agy), 'TEST FAILED: s1 manage own AGY record';
  assert not app_private.can_view_record(auth.uid(), scl), 'TEST FAILED: s1 record in unassigned vertical';
  assert not app_private.can_view_record('00000000-0000-0000-0000-0000000000b1', agy),
    'TEST FAILED: s1 viewed manager record';
end $$;

:as_mgr
do $$ declare agy uuid; scl uuid; begin
  select id into agy from public.verticals where code = 'AGY';
  select id into scl from public.verticals where code = 'SCL';
  assert app_private.can_view_record('00000000-0000-0000-0000-0000000000d1', agy),
    'TEST FAILED: manager view team record';
  assert app_private.can_manage_record('00000000-0000-0000-0000-0000000000d1', agy),
    'TEST FAILED: manager manage team record';
  assert not app_private.can_view_record('00000000-0000-0000-0000-0000000000d2', scl),
    'TEST FAILED: manager viewed non-team record';
  assert not app_private.can_view_record('00000000-0000-0000-0000-0000000000d1', scl),
    'TEST FAILED: manager viewed team record in unassigned vertical';
end $$;

:as_cxo
do $$ declare scl uuid; begin
  select id into scl from public.verticals where code = 'SCL';
  assert app_private.can_view_record('00000000-0000-0000-0000-0000000000d2', scl),
    'TEST FAILED: cxo view any record';
  assert not app_private.can_manage_record('00000000-0000-0000-0000-0000000000d2', scl),
    'TEST FAILED: cxo should be view-only on business records';
end $$;

:as_admin
do $$ declare scl uuid; begin
  select id into scl from public.verticals where code = 'SCL';
  assert app_private.can_manage_record('00000000-0000-0000-0000-0000000000d2', scl),
    'TEST FAILED: admin manage any record';
end $$;

:as_inact
do $$ declare agy uuid; begin
  select id into agy from public.verticals limit 1; -- sees none, so agy is null
  assert not coalesce(app_private.can_view_record(auth.uid(), agy), false),
    'TEST FAILED: inactive user can view records';
end $$;

reset role;
\echo 'ALL RLS TESTS PASSED'
rollback;
