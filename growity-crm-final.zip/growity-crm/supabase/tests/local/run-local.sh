#!/usr/bin/env bash
# Rebuilds a throwaway local database, applies the real migrations on top of a
# minimal Supabase auth shim, then runs the RLS test suite.
# Usage: PGHOST=/tmp PGPORT=54329 PGUSER=postgres ./supabase/tests/local/run-local.sh
set -euo pipefail
DIR="$(cd "$(dirname "$0")/../.." && pwd)"
DB=growity_rls_test
psql -v ON_ERROR_STOP=1 -qd postgres -c "drop database if exists $DB" -c "create database $DB"
psql -v ON_ERROR_STOP=1 -qd $DB -f "$DIR/tests/local/00_supabase_shim.sql"
for f in "$DIR"/migrations/*.sql; do
  echo "→ applying $(basename "$f")"
  psql -v ON_ERROR_STOP=1 -qd $DB -f "$f"
done
psql -v ON_ERROR_STOP=1 -qd $DB -f "$DIR/seed.sql"
echo "→ running RLS tests"
psql -v ON_ERROR_STOP=1 -qd $DB -f "$DIR/tests/rls_policies.test.sql"
