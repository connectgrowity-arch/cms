# Growity CRM V1 · Phase 1 Completion Report

**Date:** 15 Nov 2026 · **Status:** code complete and tested locally. Live Supabase connection pending (see 8).

## 1. Features developed
- Email/password authentication: login, forgot password, reset password, logout. Public sign-up is disabled.
- Session handling via `@supabase/ssr` middleware (token verified with `getUser()` on every request) and protected routes.
- Profiles with 4 roles (admin, CXO, manager, salesperson), reporting lines and active/inactive status.
- 3 seeded verticals, many-to-many user assignment, and a global vertical selector that remembers the last choice (validated server-side).
- RLS on every table, a column-level guard trigger, and secure helper functions in a private schema.
- Permission foundation for future business tables (`can_view_record`, `can_manage_record`).
- Responsive SaaS shell: collapsible mobile drawer, fixed desktop sidebar, top bar with vertical selector, search and notification placeholders, and a user menu showing name and role.
- Dashboard with 4 KPI cards (honest zeros), 4 placeholder sections and the onboarding message.
- Admin user management: list, search, filter by role or vertical, view and edit details, activate/deactivate, and add users through a server-only provisioning flow.
- Settings page showing company settings and verticals (read-only).
- Loading skeletons, error boundary, empty states and a 404 page.

## 2. Database tables
`profiles`, `verticals`, `user_verticals`, `app_settings`, plus the `app_private` schema for helpers.

## 3. Relationships
`profiles.id → auth.users.id` (cascade) · `profiles.manager_id → profiles.id` (set null) · `user_verticals.user_id → profiles.id` (cascade) · `user_verticals.vertical_id → verticals.id` (cascade) · unique `(user_id, vertical_id)` · case-insensitive unique email.

## 4. RLS policies
See README §5.3 for the full matrix. Summary:
- anon has no access at all
- inactive users see nothing
- admin has full control
- CXO can view everything but cannot administer
- managers see their reporting tree and its vertical assignments
- salespeople see themselves and their manager
- users may edit only their own name and phone
- only admins assign verticals and change settings

## 5. Authentication configuration
- Supabase email provider.
- Sign-ups must be turned off in the dashboard (README §2.3). As a backstop, self-signups would start inactive anyway.
- Users are created through `auth.admin.createUser`, but only after the server confirms the caller is an active admin. Role, manager and verticals are then written with the admin's own RLS-checked session.
- Password reset uses the `token_hash` template (works across devices). The PKCE `?code=` flow is also supported.
- Login errors never reveal whether an email exists. `?next=` redirects are same-site only.

## 6. Screens
`/login`, `/forgot-password`, `/reset-password`, `/dashboard`, `/settings`, `/settings/users`, `/settings/users/[id]`, plus the add-user dialog and deactivate confirmation.

## 7. Tests completed
| # | Requirement | Result |
|---|---|---|
| 1 | App starts | ✅ production build and `next start` |
| 2 | Supabase connection | ⏳ client code done; no live project connected yet (your choice) |
| 3–5 | Login / invalid login / logout | ⚠️ logout and redirect flow verified over HTTP; error-message mapping unit-tested; **live sign-in not run** (no Auth server reachable in the build environment) |
| 6 | Protected routes | ✅ HTTP smoke tests + unit tests (incl. open-redirect) |
| 7–8 | Role differentiation and enforcement | ✅ RLS suite (40+ assertions) + unit tests |
| 9 | Vertical assignments | ✅ RLS suite (admin assign, user visibility, non-admin denied) |
| 10 | Unauthorized DB requests rejected | ✅ RLS suite (anon, escalation, cross-user writes, internal helpers) |
| 11 | Dashboard loads | ✅ rendered against a mock API |
| 12 | Mobile | ✅ 390 px screenshots of all screens, no horizontal overflow |
| 13 | No secrets in bundle | ✅ `check:secrets` with a canary secret key |

The RLS suite was also mutation-tested: disabling the role guard makes it fail, as expected.
Unit: 31/31 passing. TypeScript strict, ESLint clean.

## 8. Outstanding issues
1. **Connect a Supabase project** (README §2), then run `supabase/tests/rls_policies.test.sql` against it and do a live login test. These are the last two acceptance checks.
2. RLS tests ran on Postgres 16 with a minimal auth shim, not on Supabase's own image. The migrations use only standard Supabase features, but please run the suite once on the real project.
3. Decision to confirm: **CXO is read-only on business records** (`can_manage_record` returns false). The spec says "access business records". This is a one-line change if CXOs should edit too.
4. Settings are display-only. Editing company settings and verticals is deferred.
5. Email changes are done in the Supabase dashboard (they sync to `profiles` automatically).
6. Vertical descriptions are left empty rather than invented.

## 9. Environment variables
`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` (or `NEXT_PUBLIC_SUPABASE_ANON_KEY`), `NEXT_PUBLIC_SITE_URL`, `SUPABASE_SECRET_KEY` (server only). See README §3.

## 10. How to run
`npm install` → fill in `.env.local` → `npm run dev`. See README §1–2.

## 11. Deployment
Vercel or any Node 20+ host. See README §7.

## 12. Recommended next phase
**Phase 2 – Lead management:**
- `leads` table with `vertical_id`, `owner_id`, source and status, using the existing `can_view_record` / `can_manage_record` policies
- lead list, create/edit, assignment and import
- wire the dashboard's Total/New Leads to `getDashboardMetrics()`

After that: follow-ups and activities, then opportunities and pipeline.
