import { describe, expect, it } from "vitest";
import { decideRoute, safeNextPath } from "@/lib/auth/routes";

describe("decideRoute", () => {
  it("sends signed-out users to login, keeping the destination", () => {
    expect(decideRoute("/dashboard", false)).toEqual({ action: "redirect", to: "/login?next=%2Fdashboard" });
    expect(decideRoute("/settings/users", false)).toEqual({
      action: "redirect",
      to: "/login?next=%2Fsettings%2Fusers",
    });
    expect(decideRoute("/", false)).toEqual({ action: "redirect", to: "/login" });
  });

  it("protects the reset page (needs a recovery session)", () => {
    expect(decideRoute("/reset-password", false).action).toBe("redirect");
    expect(decideRoute("/reset-password", true)).toEqual({ action: "allow" });
  });

  it("sends signed-in users away from login", () => {
    expect(decideRoute("/login", true)).toEqual({ action: "redirect", to: "/dashboard" });
    expect(decideRoute("/forgot-password", true)).toEqual({ action: "redirect", to: "/dashboard" });
    expect(decideRoute("/", true)).toEqual({ action: "redirect", to: "/dashboard" });
  });

  it("always allows auth callbacks", () => {
    expect(decideRoute("/auth/confirm", false)).toEqual({ action: "allow" });
    expect(decideRoute("/auth/signout", true)).toEqual({ action: "allow" });
  });

  it("does not treat look-alike paths as public", () => {
    expect(decideRoute("/login-admin", false).action).toBe("redirect");
    expect(decideRoute("/authx", false).action).toBe("redirect");
  });
});

describe("safeNextPath", () => {
  it("blocks open redirects", () => {
    expect(safeNextPath("https://evil.com")).toBe("/dashboard");
    expect(safeNextPath("//evil.com")).toBe("/dashboard");
    expect(safeNextPath("/\\evil.com")).toBe("/dashboard");
    expect(safeNextPath(null)).toBe("/dashboard");
    expect(safeNextPath("/settings/users")).toBe("/settings/users");
  });
});
