import { describe, expect, it } from "vitest";
import {
  ROLES,
  canBeManager,
  canManageSettings,
  canManageUsers,
  canSelectAllVerticals,
  hasGlobalAccess,
  isRole,
  recordScope,
  validateAdminChange,
} from "@/lib/permissions";
import { navigationForRole } from "@/config/navigation";

describe("role capabilities", () => {
  it("supports exactly the four roles", () => {
    expect([...ROLES].sort()).toEqual(["admin", "cxo", "manager", "salesperson"]);
    expect(isRole("admin")).toBe(true);
    expect(isRole("superadmin")).toBe(false);
    expect(isRole(undefined)).toBe(false);
  });

  it("differentiates admin from cxo", () => {
    expect(hasGlobalAccess("admin")).toBe(true);
    expect(hasGlobalAccess("cxo")).toBe(true);
    expect(canManageUsers("admin")).toBe(true);
    expect(canManageUsers("cxo")).toBe(false);
    expect(canManageSettings("cxo")).toBe(false);
  });

  it("limits managers and salespeople to assigned verticals", () => {
    for (const r of ["manager", "salesperson"] as const) {
      expect(hasGlobalAccess(r)).toBe(false);
      expect(canSelectAllVerticals(r)).toBe(false);
      expect(canManageUsers(r)).toBe(false);
    }
  });

  it("maps record scope like app_private.can_view_record", () => {
    expect(recordScope("admin")).toBe("all");
    expect(recordScope("cxo")).toBe("all");
    expect(recordScope("manager")).toBe("team");
    expect(recordScope("salesperson")).toBe("own");
    expect(recordScope(null)).toBe("none");
  });

  it("only manager, cxo and admin can be a manager", () => {
    expect(canBeManager("manager")).toBe(true);
    expect(canBeManager("cxo")).toBe(true);
    expect(canBeManager("admin")).toBe(true);
    expect(canBeManager("salesperson")).toBe(false);
  });

  it("denies everything to a missing role", () => {
    expect(hasGlobalAccess(null)).toBe(false);
    expect(canManageUsers(undefined)).toBe(false);
  });
});

describe("validateAdminChange", () => {
  const admin = { actorId: "a", actorRole: "admin" as const };

  it("rejects non-admin actors", () => {
    expect(validateAdminChange({ actorId: "m", actorRole: "manager", targetId: "s" }).ok).toBe(false);
    expect(validateAdminChange({ actorId: "c", actorRole: "cxo", targetId: "s", nextRole: "admin" }).ok).toBe(false);
  });

  it("stops admins locking themselves out", () => {
    expect(validateAdminChange({ ...admin, targetId: "a", nextActive: false }).ok).toBe(false);
    expect(validateAdminChange({ ...admin, targetId: "a", nextRole: "cxo" }).ok).toBe(false);
    expect(validateAdminChange({ ...admin, targetId: "a", nextRole: "admin" }).ok).toBe(true);
  });

  it("lets admins change other users", () => {
    expect(validateAdminChange({ ...admin, targetId: "s", nextRole: "manager" }).ok).toBe(true);
    expect(validateAdminChange({ ...admin, targetId: "s", nextActive: false }).ok).toBe(true);
  });
});

describe("navigation", () => {
  const hrefs = (role: Parameters<typeof navigationForRole>[0]) =>
    navigationForRole(role).flatMap((s) => s.items.map((i) => i.href));

  it("shows admin links only to admins", () => {
    expect(hrefs("admin")).toContain("/settings/users");
    for (const r of ["cxo", "manager", "salesperson"] as const) {
      expect(hrefs(r)).not.toContain("/settings/users");
      expect(hrefs(r)).not.toContain("/settings");
    }
  });

  it("marks future modules as coming soon", () => {
    const soon = navigationForRole("admin")
      .flatMap((s) => s.items)
      .filter((i) => i.comingSoon)
      .map((i) => i.label);
    expect(soon).toEqual([
      "Leads", "Customers", "Opportunities", "Pipeline", "Follow-ups", "Activities", "Sales Reports",
    ]);
  });
});
