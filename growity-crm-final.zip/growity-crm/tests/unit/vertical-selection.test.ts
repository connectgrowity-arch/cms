import { describe, expect, it } from "vitest";
import { ALL_VERTICALS, isValidSelection, resolveSelectedVertical } from "@/lib/verticals/selection";

const all = [
  { id: "1", code: "AGY", name: "Growity Agency" },
  { id: "2", code: "SCL", name: "Scaler" },
  { id: "3", code: "ACD", name: "Growity Academy" },
];
const agyOnly = [all[0]!];

describe("resolveSelectedVertical", () => {
  it("defaults admin and cxo to All Verticals", () => {
    expect(resolveSelectedVertical(undefined, "admin", all)).toBe(ALL_VERTICALS);
    expect(resolveSelectedVertical(undefined, "cxo", all)).toBe(ALL_VERTICALS);
  });

  it("remembers a valid previous choice", () => {
    expect(resolveSelectedVertical("SCL", "cxo", all)).toBe("SCL");
    expect(resolveSelectedVertical("AGY", "salesperson", agyOnly)).toBe("AGY");
  });

  it("ignores a tampered cookie", () => {
    expect(resolveSelectedVertical(ALL_VERTICALS, "salesperson", agyOnly)).toBe("AGY");
    expect(resolveSelectedVertical("SCL", "manager", agyOnly)).toBe("AGY");
    expect(resolveSelectedVertical("'; drop table", "salesperson", agyOnly)).toBe("AGY");
  });

  it("returns null when nothing is assigned", () => {
    expect(resolveSelectedVertical(undefined, "salesperson", [])).toBeNull();
  });
});

describe("isValidSelection", () => {
  it("only lets admin/cxo pick All Verticals", () => {
    expect(isValidSelection(ALL_VERTICALS, "admin", all)).toBe(true);
    expect(isValidSelection(ALL_VERTICALS, "manager", agyOnly)).toBe(false);
  });
  it("rejects verticals the user can't see", () => {
    expect(isValidSelection("SCL", "salesperson", agyOnly)).toBe(false);
    expect(isValidSelection("AGY", "salesperson", agyOnly)).toBe(true);
  });
});
