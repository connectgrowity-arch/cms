import { describe, expect, it } from "vitest";
import { loginSchema, resetPasswordSchema } from "@/lib/validations/auth";
import { createUserSchema, userFiltersSchema } from "@/lib/validations/users";
import { loginErrorMessage } from "@/lib/utils/auth-errors";

const validUser = {
  fullName: "Asha K",
  email: "Asha@Growity.in ",
  phone: "",
  role: "salesperson",
  managerId: "",
  verticalIds: [],
  temporaryPassword: "Welcome123",
};

describe("auth validation", () => {
  it("normalises email and requires a password", () => {
    expect(loginSchema.parse({ email: " A@B.co ", password: "x" }).email).toBe("a@b.co");
    expect(loginSchema.safeParse({ email: "a@b.co", password: "" }).success).toBe(false);
  });
  it("enforces password rules and matching confirmation", () => {
    expect(resetPasswordSchema.safeParse({ password: "short1", confirmPassword: "short1" }).success).toBe(false);
    expect(resetPasswordSchema.safeParse({ password: "longenough", confirmPassword: "longenough" }).success).toBe(false);
    expect(resetPasswordSchema.safeParse({ password: "Growity2026", confirmPassword: "Growity2027" }).success).toBe(false);
    expect(resetPasswordSchema.safeParse({ password: "Growity2026", confirmPassword: "Growity2026" }).success).toBe(true);
  });
});

describe("user validation", () => {
  it("accepts a valid user and normalises empty fields", () => {
    const r = createUserSchema.parse(validUser);
    expect(r.email).toBe("asha@growity.in");
    expect(r.phone).toBeNull();
    expect(r.managerId).toBeNull();
  });
  it("rejects unknown roles", () => {
    expect(createUserSchema.safeParse({ ...validUser, role: "superadmin" }).success).toBe(false);
  });
  it("rejects non-uuid manager and vertical ids", () => {
    expect(createUserSchema.safeParse({ ...validUser, managerId: "1 or 1=1" }).success).toBe(false);
    expect(createUserSchema.safeParse({ ...validUser, verticalIds: ["AGY"] }).success).toBe(false);
  });
  it("drops invalid filter values instead of failing", () => {
    expect(userFiltersSchema.parse({ role: "hacker", vertical: "agy;--" })).toEqual({
      q: undefined,
      role: undefined,
      vertical: undefined,
    });
    expect(userFiltersSchema.parse({ role: "manager", vertical: "AGY" }).role).toBe("manager");
  });
});

describe("login error messages", () => {
  it("never reveals whether an email exists", () => {
    const msg = loginErrorMessage({ code: "invalid_credentials", message: "Invalid login credentials" });
    expect(msg).toMatch(/incorrect email or password/i);
  });
  it("explains rate limits", () => {
    expect(loginErrorMessage({ status: 429, message: "" })).toMatch(/too many attempts/i);
  });
});
