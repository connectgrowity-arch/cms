"use client";

import { useContext } from "react";
import { VerticalContext } from "@/components/layout/vertical-context";

/** The globally selected vertical, available to any client component in the app. */
export function useVertical() {
  const ctx = useContext(VerticalContext);
  if (!ctx) throw new Error("useVertical must be used inside the app layout");
  return ctx;
}
