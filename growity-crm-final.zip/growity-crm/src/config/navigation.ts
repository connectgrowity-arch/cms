import {
  LayoutDashboard,
  UserPlus,
  Building2,
  Target,
  KanbanSquare,
  CalendarClock,
  Activity,
  BarChart3,
  Users,
  Settings,
  type LucideIcon,
} from "lucide-react";
import type { AppRole } from "@/types/database";

export type NavItem = {
  label: string;
  href: string;
  icon: LucideIcon;
  comingSoon?: boolean;
  roles?: AppRole[]; // omitted = everyone
};

export type NavSection = { title: string; items: NavItem[] };

export const NAVIGATION: NavSection[] = [
  {
    title: "Main",
    items: [
      { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
      { label: "Leads", href: "/leads", icon: UserPlus, comingSoon: true },
      { label: "Customers", href: "/customers", icon: Building2, comingSoon: true },
      { label: "Opportunities", href: "/opportunities", icon: Target, comingSoon: true },
      { label: "Pipeline", href: "/pipeline", icon: KanbanSquare, comingSoon: true },
      { label: "Follow-ups", href: "/follow-ups", icon: CalendarClock, comingSoon: true },
      { label: "Activities", href: "/activities", icon: Activity, comingSoon: true },
    ],
  },
  {
    title: "Reports",
    items: [{ label: "Sales Reports", href: "/reports", icon: BarChart3, comingSoon: true }],
  },
  {
    title: "Admin",
    items: [
      { label: "Users", href: "/settings/users", icon: Users, roles: ["admin"] },
      { label: "Settings", href: "/settings", icon: Settings, roles: ["admin"] },
    ],
  },
];

export function navigationForRole(role: AppRole): NavSection[] {
  return NAVIGATION.map((s) => ({
    ...s,
    items: s.items.filter((i) => !i.roles || i.roles.includes(role)),
  })).filter((s) => s.items.length > 0);
}
