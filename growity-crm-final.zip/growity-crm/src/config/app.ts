// Static defaults. Live values are stored in public.app_settings.
export const APP_CONFIG = {
  name: "Growity CRM",
  company: "Growity Solutions",
  currency: "INR",
  timezone: "Asia/Kolkata",
  fiscalYearStartMonth: 4,
} as const;
