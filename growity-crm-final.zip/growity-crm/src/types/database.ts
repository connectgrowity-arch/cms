// Hand-written to match supabase/migrations. Regenerate with:
//   npx supabase gen types typescript --project-id <ref> > src/types/database.ts
export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type AppRole = "admin" | "cxo" | "manager" | "salesperson";

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          full_name: string;
          email: string;
          phone: string | null;
          role: AppRole;
          manager_id: string | null;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: never;
        Update: {
          full_name?: string;
          phone?: string | null;
          role?: AppRole;
          manager_id?: string | null;
          is_active?: boolean;
        };
        Relationships: [];
      };
      verticals: {
        Row: {
          id: string;
          code: string;
          name: string;
          description: string | null;
          is_active: boolean;
          created_at: string;
        };
        Insert: { code: string; name: string; description?: string | null; is_active?: boolean };
        Update: { code?: string; name?: string; description?: string | null; is_active?: boolean };
        Relationships: [];
      };
      user_verticals: {
        Row: { id: string; user_id: string; vertical_id: string; created_at: string };
        Insert: { user_id: string; vertical_id: string };
        Update: never;
        Relationships: [];
      };
      app_settings: {
        Row: { id: string; setting_key: string; setting_value: Json; updated_at: string };
        Insert: { setting_key: string; setting_value: Json };
        Update: { setting_value?: Json };
        Relationships: [];
      };
    };
    Views: Record<string, never>;
    Functions: {
      admin_list_users: {
        Args: { p_search?: string | null; p_role?: string | null; p_vertical_code?: string | null };
        Returns: {
          id: string;
          full_name: string;
          email: string;
          phone: string | null;
          role: AppRole;
          is_active: boolean;
          created_at: string;
          manager_id: string | null;
          manager_name: string | null;
          vertical_codes: string[];
        }[];
      };
      admin_set_user_verticals: {
        Args: { p_user_id: string; p_vertical_ids: string[] };
        Returns: undefined;
      };
    };
    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
  };
};

export type Profile = Database["public"]["Tables"]["profiles"]["Row"];
export type Vertical = Database["public"]["Tables"]["verticals"]["Row"];
export type AdminUserRow = Database["public"]["Functions"]["admin_list_users"]["Returns"][number];
