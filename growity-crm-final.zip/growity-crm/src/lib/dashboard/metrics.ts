import "server-only";

/**
 * Dashboard metrics contract. Phase 1 has no business tables yet, so every
 * metric resolves to an honest zero. When leads/opportunities land, replace
 * the body with RLS-bound queries filtered by `vertical` (null = all).
 */
export type DashboardMetrics = {
  totalLeads: number;
  newLeads: number;
  activeOpportunities: number;
  wonRevenue: number; // INR
  hasData: boolean;
};

export async function getDashboardMetrics(vertical: string | null): Promise<DashboardMetrics> {
  void vertical;
  return { totalLeads: 0, newLeads: 0, activeOpportunities: 0, wonRevenue: 0, hasData: false };
}
