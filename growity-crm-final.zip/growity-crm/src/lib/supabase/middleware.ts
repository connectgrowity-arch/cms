import { NextResponse, type NextRequest } from "next/server";
import { createServerClient } from "@supabase/ssr";
import type { Database } from "@/types/database";
import { decideRoute } from "@/lib/auth/routes";
import { isSupabaseConfigured } from "./env";

export async function updateSession(request: NextRequest) {
  if (!isSupabaseConfigured()) {
    // Let the page render its configuration error instead of crashing middleware.
    return NextResponse.next({ request });
  }

  let response = NextResponse.next({ request });

  const supabase = createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    (process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          response = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, options),
          );
        },
      },
    },
  );

  // getUser() validates the token with Supabase Auth on every request,
  // unlike getSession() which only reads the cookie.
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const decision = decideRoute(request.nextUrl.pathname, Boolean(user));
  if (decision.action === "redirect") {
    const url = request.nextUrl.clone();
    const [pathname, search] = decision.to.split("?");
    url.pathname = pathname;
    url.search = search ? `?${search}` : "";
    const redirect = NextResponse.redirect(url);
    // carry refreshed auth cookies over to the redirect
    response.cookies.getAll().forEach((c) => redirect.cookies.set(c));
    return redirect;
  }

  return response;
}
