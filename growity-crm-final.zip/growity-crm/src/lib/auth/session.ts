import "server-only";
import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { canManageUsers } from "@/lib/permissions";
import {
  VERTICAL_COOKIE,
  resolveSelectedVertical,
  type VerticalOption,
} from "@/lib/verticals/selection";
import type { Profile } from "@/types/database";

export type SessionContext = {
  profile: Profile;
  verticals: VerticalOption[];
  selectedVertical: string | null;
};

/**
 * Load the signed-in user, their profile and accessible verticals once per
 * request (React cache dedupes calls from layout + page).
 * Identity comes from supabase.auth.getUser(), which verifies the JWT.
 */
export const getSessionContext = cache(async (): Promise<SessionContext | null> => {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const [{ data: profile }, { data: verticals }] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle(),
    // RLS returns only the verticals this user may access
    supabase.from("verticals").select("id, code, name").eq("is_active", true).order("name"),
  ]);

  // RLS hides the profile row when the account is inactive
  if (!profile || !profile.is_active) return null;

  const cookieStore = await cookies();
  const options = verticals ?? [];
  return {
    profile,
    verticals: options,
    selectedVertical: resolveSelectedVertical(
      cookieStore.get(VERTICAL_COOKIE)?.value,
      profile.role,
      options,
    ),
  };
});

/** Use in protected layouts/pages. Signed-in but inactive users are signed out. */
export async function requireSession(): Promise<SessionContext> {
  const ctx = await getSessionContext();
  if (!ctx) {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    redirect(user ? "/auth/signout?reason=inactive" : "/login");
  }
  return ctx;
}

export async function requireAdmin(): Promise<SessionContext> {
  const ctx = await requireSession();
  if (!canManageUsers(ctx.profile.role)) redirect("/dashboard?denied=1");
  return ctx;
}
