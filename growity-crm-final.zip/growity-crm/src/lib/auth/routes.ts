// Pure routing rules, shared by middleware and unit tests.

/** Pages for signed-out users. Signed-in users are sent to the dashboard. */
export const GUEST_ONLY_ROUTES = ["/login", "/forgot-password"] as const;

/** Reachable whether or not the user is signed in (auth callbacks). */
export const PUBLIC_ROUTES = ["/auth/confirm", "/auth/signout"] as const;

export const LOGIN_PATH = "/login";
export const HOME_PATH = "/dashboard";

function matches(pathname: string, route: string) {
  return pathname === route || pathname.startsWith(`${route}/`);
}

export type RouteDecision =
  | { action: "allow" }
  | { action: "redirect"; to: string };

export function decideRoute(pathname: string, isAuthenticated: boolean): RouteDecision {
  if (PUBLIC_ROUTES.some((r) => matches(pathname, r))) return { action: "allow" };

  const guestOnly = GUEST_ONLY_ROUTES.some((r) => matches(pathname, r));
  if (guestOnly) {
    return isAuthenticated ? { action: "redirect", to: HOME_PATH } : { action: "allow" };
  }

  if (!isAuthenticated) {
    const next = pathname && pathname !== "/" ? `?next=${encodeURIComponent(pathname)}` : "";
    return { action: "redirect", to: `${LOGIN_PATH}${next}` };
  }

  if (pathname === "/") return { action: "redirect", to: HOME_PATH };
  return { action: "allow" };
}

/** Only allow same-site relative redirects (prevents open-redirects via ?next=). */
export function safeNextPath(next: string | null | undefined, fallback = HOME_PATH) {
  if (!next || !next.startsWith("/") || next.startsWith("//") || next.startsWith("/\\")) {
    return fallback;
  }
  return next;
}
