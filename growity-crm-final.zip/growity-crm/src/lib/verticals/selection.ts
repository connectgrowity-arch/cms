// Pure logic for the global vertical selector (shared by server and tests).
import type { AppRole } from "@/types/database";
import { canSelectAllVerticals } from "@/lib/permissions";

export const VERTICAL_COOKIE = "growity_vertical";
export const ALL_VERTICALS = "ALL";

export type VerticalOption = { id: string; code: string; name: string };

/**
 * Resolve which vertical is active for this request.
 * The cookie is only a preference: it is validated against the verticals the
 * database says this user can see, so a tampered cookie can't widen access.
 */
export function resolveSelectedVertical(
  cookieValue: string | undefined,
  role: AppRole | null | undefined,
  accessible: VerticalOption[],
): string | null {
  const allowAll = canSelectAllVerticals(role);

  if (cookieValue === ALL_VERTICALS && allowAll) return ALL_VERTICALS;
  if (cookieValue && accessible.some((v) => v.code === cookieValue)) return cookieValue;

  if (allowAll) return ALL_VERTICALS;
  return accessible[0]?.code ?? null;
}

export function isValidSelection(
  value: string,
  role: AppRole | null | undefined,
  accessible: VerticalOption[],
) {
  if (value === ALL_VERTICALS) return canSelectAllVerticals(role);
  return accessible.some((v) => v.code === value);
}
