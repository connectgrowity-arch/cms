import { z } from "zod";
import { emailSchema, passwordSchema } from "./auth";

export const roleSchema = z.enum(["admin", "cxo", "manager", "salesperson"]);

const phoneSchema = z
  .string()
  .trim()
  .max(20, "Use 20 characters or fewer.")
  .regex(/^[+0-9 ()-]*$/, "Use digits, spaces, +, - or brackets only.")
  .transform((v) => (v === "" ? null : v));

const uuid = z.guid();

export const createUserSchema = z.object({
  fullName: z.string().trim().min(1, "Enter the user's full name.").max(120),
  email: emailSchema,
  phone: phoneSchema,
  role: roleSchema,
  managerId: z
    .string()
    .transform((v) => (v === "" ? null : v))
    .pipe(uuid.nullable()),
  verticalIds: z.array(uuid).default([]),
  temporaryPassword: passwordSchema,
});

export const updateUserSchema = z.object({
  userId: uuid,
  fullName: z.string().trim().min(1, "Enter the user's full name.").max(120),
  phone: phoneSchema,
  role: roleSchema,
  managerId: z
    .string()
    .transform((v) => (v === "" ? null : v))
    .pipe(uuid.nullable()),
  verticalIds: z.array(uuid).default([]),
});

export const setActiveSchema = z.object({ userId: uuid, isActive: z.boolean() });

export const userFiltersSchema = z.object({
  q: z.string().trim().max(100).optional().catch(undefined),
  role: roleSchema.optional().catch(undefined),
  vertical: z
    .string()
    .regex(/^[A-Z]{2,10}$/)
    .optional()
    .catch(undefined),
});

export type CreateUserInput = z.input<typeof createUserSchema>;
export type UpdateUserInput = z.input<typeof updateUserSchema>;
