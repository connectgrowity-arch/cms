import "server-only";
import { createClient } from "@/lib/supabase/server";

/** Data needed by the add/edit user forms. All reads go through RLS (admin). */
export async function getUserFormOptions() {
  const supabase = await createClient();
  const [{ data: verticals }, { data: managers }] = await Promise.all([
    supabase.from("verticals").select("id, code, name").order("name"),
    supabase
      .from("profiles")
      .select("id, full_name, role")
      .in("role", ["manager", "cxo", "admin"])
      .eq("is_active", true)
      .order("full_name"),
  ]);
  return { verticals: verticals ?? [], managers: managers ?? [] };
}

export type UserFormOptions = Awaited<ReturnType<typeof getUserFormOptions>>;
