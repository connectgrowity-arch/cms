// Map Supabase Auth errors to clear, non-technical messages.
// Login errors never reveal whether an email exists.
export function loginErrorMessage(error: { message?: string; code?: string; status?: number } | null) {
  if (!error) return null;
  const code = error.code ?? "";
  const msg = (error.message ?? "").toLowerCase();

  if (code === "invalid_credentials" || msg.includes("invalid login credentials"))
    return "Incorrect email or password. Check your details and try again.";
  if (code === "email_not_confirmed" || msg.includes("email not confirmed"))
    return "Your email address hasn't been confirmed yet. Ask your admin to resend the invite.";
  if (code === "user_banned" || msg.includes("banned"))
    return "This account has been disabled. Contact your admin.";
  if (code === "over_request_rate_limit" || error.status === 429 || msg.includes("rate limit"))
    return "Too many attempts. Wait a minute and try again.";
  if (msg.includes("fetch") || msg.includes("network"))
    return "We couldn't reach the server. Check your connection and try again.";
  return "We couldn't sign you in. Try again, or contact your admin if this keeps happening.";
}
