import type { AppRole } from "@/types/database";

/**
 * UI-level permission helpers.
 *
 * These only decide what to SHOW. Every rule here is also enforced in the
 * database by RLS (supabase/migrations/*_rls_policies.sql), which is the real
 * security boundary. Keep the two in sync.
 */

export const ROLES: readonly AppRole[] = ["admin", "cxo", "manager", "salesperson"] as const;

export const ROLE_LABELS: Record<AppRole, string> = {
  admin: "Admin",
  cxo: "CXO",
  manager: "Manager",
  salesperson: "Salesperson",
};

export function isRole(value: unknown): value is AppRole {
  return typeof value === "string" && (ROLES as readonly string[]).includes(value);
}

/** Admin and CXO see every vertical and company-wide dashboards. */
export function hasGlobalAccess(role: AppRole | null | undefined) {
  return role === "admin" || role === "cxo";
}

export function canManageUsers(role: AppRole | null | undefined) {
  return role === "admin";
}

export function canManageSettings(role: AppRole | null | undefined) {
  return role === "admin";
}

export function canSelectAllVerticals(role: AppRole | null | undefined) {
  return hasGlobalAccess(role);
}

/** Roles that may be set as someone's manager (mirrors guard_profile_update). */
export function canBeManager(role: AppRole | null | undefined) {
  return role === "manager" || role === "cxo" || role === "admin";
}

/** Business-record scope used by future modules (mirrors app_private.can_view_record). */
export type RecordScope = "all" | "team" | "own" | "none";
export function recordScope(role: AppRole | null | undefined): RecordScope {
  switch (role) {
    case "admin":
    case "cxo":
      return "all";
    case "manager":
      return "team";
    case "salesperson":
      return "own";
    default:
      return "none";
  }
}

/**
 * Whether an admin may apply a change to a target user from the UI.
 * The database enforces the same rules (and more) in guard_profile_update.
 */
export function validateAdminChange(params: {
  actorId: string;
  actorRole: AppRole;
  targetId: string;
  nextRole?: AppRole;
  nextActive?: boolean;
}): { ok: true } | { ok: false; reason: string } {
  const { actorId, actorRole, targetId, nextRole, nextActive } = params;
  if (actorRole !== "admin") return { ok: false, reason: "Only admins can manage users." };
  if (actorId === targetId) {
    if (nextActive === false) return { ok: false, reason: "You can't deactivate your own account." };
    if (nextRole && nextRole !== "admin")
      return { ok: false, reason: "You can't remove your own admin role." };
  }
  return { ok: true };
}
