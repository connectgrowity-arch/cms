import type { Metadata } from "next";
import { BrandMark } from "@/components/layout/brand-mark";
import { ResetPasswordForm } from "@/components/forms/reset-password-form";

export const metadata: Metadata = { title: "Set new password · Growity CRM" };

// Reached from the email link via /auth/confirm, which creates a recovery session.
// Middleware sends anyone without a session to /login.
export default function ResetPasswordPage() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center bg-slate-50 px-4 py-10">
      <div className="mb-6">
        <BrandMark />
      </div>
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        <div className="mb-5">
          <h1 className="text-xl font-semibold">Set a new password</h1>
          <p className="mt-1 text-sm text-slate-500">
            At least 8 characters, with a letter and a number.
          </p>
        </div>
        <ResetPasswordForm />
      </div>
    </main>
  );
}
