import { redirect } from "next/navigation";

// Middleware already routes "/" (dashboard if signed in, login if not).
export default function Home() {
  redirect("/dashboard");
}
