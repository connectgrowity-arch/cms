import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-3 px-4 text-center">
      <p className="text-sm font-medium text-brand-600">404</p>
      <h1 className="text-xl font-semibold">Page not found</h1>
      <p className="text-sm text-slate-500">This page doesn&apos;t exist or you don&apos;t have access to it.</p>
      <Link href="/dashboard" className="text-sm font-medium text-brand-600 hover:underline">Go to dashboard</Link>
    </main>
  );
}
