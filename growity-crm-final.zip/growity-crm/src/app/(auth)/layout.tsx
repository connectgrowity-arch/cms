import { BrandMark } from "@/components/layout/brand-mark";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center bg-slate-50 px-4 py-10">
      <div className="mb-6">
        <BrandMark />
      </div>
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        {children}
      </div>
      <p className="mt-6 text-xs text-slate-500">© Growity Solutions</p>
    </main>
  );
}
