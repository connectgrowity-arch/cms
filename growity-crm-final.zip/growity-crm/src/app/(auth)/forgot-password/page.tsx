import type { Metadata } from "next";
import Link from "next/link";
import { ForgotPasswordForm } from "@/components/forms/forgot-password-form";

export const metadata: Metadata = { title: "Forgot password · Growity CRM" };

export default function ForgotPasswordPage() {
  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-xl font-semibold">Reset your password</h1>
        <p className="mt-1 text-sm text-slate-500">
          Enter your work email and we&apos;ll send you a reset link.
        </p>
      </div>
      <ForgotPasswordForm />
      <Link href="/login" className="text-center text-sm text-brand-600 hover:underline">
        Back to sign in
      </Link>
    </div>
  );
}
