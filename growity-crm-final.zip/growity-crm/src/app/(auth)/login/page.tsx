import type { Metadata } from "next";
import { LoginForm } from "@/components/forms/login-form";
import { Alert } from "@/components/ui/alert";

export const metadata: Metadata = { title: "Sign in · Growity CRM" };

const NOTICES: Record<string, { variant: "info" | "error" | "success"; text: string }> = {
  "signed-out": { variant: "success", text: "You've been signed out." },
  inactive: {
    variant: "error",
    text: "Your account is inactive. Contact your Growity admin to regain access.",
  },
};

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; notice?: string; error?: string }>;
}) {
  const { next, notice, error } = await searchParams;
  const n = notice ? NOTICES[notice] : undefined;

  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-xl font-semibold">Sign in</h1>
        <p className="mt-1 text-sm text-slate-500">Use the account your admin created for you.</p>
      </div>
      {n && <Alert variant={n.variant}>{n.text}</Alert>}
      {error === "link" && (
        <Alert variant="error">That link is invalid or has expired. Request a new one.</Alert>
      )}
      <LoginForm next={next} />
    </div>
  );
}
