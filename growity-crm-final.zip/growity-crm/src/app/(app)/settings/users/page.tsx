import type { Metadata } from "next";
import Link from "next/link";
import { Users, SearchX } from "lucide-react";
import { requireAdmin } from "@/lib/auth/session";
import { createClient } from "@/lib/supabase/server";
import { getUserFormOptions } from "@/lib/users/queries";
import { userFiltersSchema } from "@/lib/validations/users";
import { ROLE_LABELS } from "@/lib/permissions";
import { formatDate } from "@/lib/utils/format";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert } from "@/components/ui/alert";
import { EmptyState } from "@/components/ui/empty-state";
import { AddUserDialog } from "@/components/users/add-user-dialog";
import { UserFilters } from "@/components/users/user-filters";
import { UserStatusToggle } from "@/components/users/user-status-toggle";
import type { AdminUserRow } from "@/types/database";

export const metadata: Metadata = { title: "Users · Growity CRM" };

function StatusBadge({ active }: { active: boolean }) {
  return <Badge variant={active ? "success" : "muted"}>{active ? "Active" : "Inactive"}</Badge>;
}

function VerticalBadges({ codes }: { codes: string[] }) {
  if (!codes.length) return <span className="text-slate-400">None</span>;
  return (
    <div className="flex flex-wrap gap-1">
      {codes.map((c) => (
        <Badge key={c} variant="brand">
          {c}
        </Badge>
      ))}
    </div>
  );
}

export default async function UsersPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const [{ profile: actor }, raw] = await Promise.all([requireAdmin(), searchParams]);
  const filters = userFiltersSchema.parse(raw);

  const supabase = await createClient();
  const [{ data: users, error }, options] = await Promise.all([
    supabase.rpc("admin_list_users", {
      p_search: filters.q ?? null,
      p_role: filters.role ?? null,
      p_vertical_code: filters.vertical ?? null,
    }),
    getUserFormOptions(),
  ]);

  const rows: AdminUserRow[] = users ?? [];
  const filtered = Boolean(filters.q || filters.role || filters.vertical);

  return (
    <div className="mx-auto flex max-w-7xl flex-col gap-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Users</h1>
          <p className="mt-1 text-sm text-slate-500">
            Manage who can sign in, their role and which verticals they work in.
          </p>
        </div>
        <AddUserDialog options={options} actorId={actor.id} />
      </div>

      <UserFilters verticals={options.verticals} />

      {error ? (
        <Alert variant="error">We couldn&apos;t load users. Refresh the page to try again.</Alert>
      ) : rows.length === 0 ? (
        filtered ? (
          <EmptyState icon={SearchX} title="No users match these filters" description="Try a different search or clear the filters." />
        ) : (
          <EmptyState icon={Users} title="No users yet" description="Add your first team member to get started." />
        )
      ) : (
        <>
          <p className="text-sm text-slate-500">
            {rows.length} {rows.length === 1 ? "user" : "users"}
          </p>

          {/* Mobile: cards */}
          <ul className="flex flex-col gap-3 md:hidden">
            {rows.map((u) => (
              <li key={u.id}>
                <Card className="flex flex-col gap-3 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <Link href={`/settings/users/${u.id}`} className="min-w-0">
                      <p className="truncate font-medium text-slate-900">{u.full_name}</p>
                      <p className="truncate text-sm text-slate-500">{u.email}</p>
                    </Link>
                    <StatusBadge active={u.is_active} />
                  </div>
                  <dl className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <dt className="text-xs text-slate-500">Role</dt>
                      <dd>{ROLE_LABELS[u.role]}</dd>
                    </div>
                    <div>
                      <dt className="text-xs text-slate-500">Manager</dt>
                      <dd>{u.manager_name ?? "—"}</dd>
                    </div>
                    <div>
                      <dt className="text-xs text-slate-500">Verticals</dt>
                      <dd><VerticalBadges codes={u.vertical_codes} /></dd>
                    </div>
                    <div>
                      <dt className="text-xs text-slate-500">Phone</dt>
                      <dd>{u.phone ?? "—"}</dd>
                    </div>
                  </dl>
                  <div className="flex items-center justify-between border-t border-slate-100 pt-3">
                    <span className="text-xs text-slate-500">Added {formatDate(u.created_at)}</span>
                    <div className="flex gap-2">
                      <Link href={`/settings/users/${u.id}`} className="inline-flex h-8 items-center rounded-lg px-3 text-xs font-medium text-brand-600 hover:bg-brand-50">
                        View
                      </Link>
                      <UserStatusToggle userId={u.id} name={u.full_name} isActive={u.is_active} disabled={u.id === actor.id} />
                    </div>
                  </div>
                </Card>
              </li>
            ))}
          </ul>

          {/* Desktop: table */}
          <Card className="hidden overflow-x-auto md:block">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  <th scope="col" className="px-4 py-3 font-medium">Name</th>
                  <th scope="col" className="px-4 py-3 font-medium">Phone</th>
                  <th scope="col" className="px-4 py-3 font-medium">Role</th>
                  <th scope="col" className="px-4 py-3 font-medium">Verticals</th>
                  <th scope="col" className="px-4 py-3 font-medium">Manager</th>
                  <th scope="col" className="px-4 py-3 font-medium">Status</th>
                  <th scope="col" className="px-4 py-3 font-medium">Created</th>
                  <th scope="col" className="px-4 py-3"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rows.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/60">
                    <td className="px-4 py-3">
                      <Link href={`/settings/users/${u.id}`} className="font-medium text-slate-900 hover:text-brand-700">
                        {u.full_name}
                      </Link>
                      <p className="text-xs text-slate-500">{u.email}</p>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-slate-600">{u.phone ?? "—"}</td>
                    <td className="px-4 py-3">{ROLE_LABELS[u.role]}</td>
                    <td className="px-4 py-3"><VerticalBadges codes={u.vertical_codes} /></td>
                    <td className="px-4 py-3 text-slate-600">{u.manager_name ?? "—"}</td>
                    <td className="px-4 py-3"><StatusBadge active={u.is_active} /></td>
                    <td className="whitespace-nowrap px-4 py-3 text-slate-600">{formatDate(u.created_at)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-2">
                        <Link href={`/settings/users/${u.id}`} className="inline-flex h-8 items-center rounded-lg px-3 text-xs font-medium text-brand-600 hover:bg-brand-50">
                          View
                        </Link>
                        <UserStatusToggle userId={u.id} name={u.full_name} isActive={u.is_active} disabled={u.id === actor.id} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </>
      )}
    </div>
  );
}
