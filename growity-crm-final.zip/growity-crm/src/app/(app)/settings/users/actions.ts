"use server";

import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/auth/session";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { validateAdminChange } from "@/lib/permissions";
import {
  createUserSchema,
  setActiveSchema,
  updateUserSchema,
  type CreateUserInput,
  type UpdateUserInput,
} from "@/lib/validations/users";

export type UserActionResult =
  | { ok: true; message: string; userId?: string }
  | { ok: false; error: string };

/** Turn Postgres errors raised by RLS / guard triggers into readable messages. */
function dbError(error: { code?: string; message?: string } | null, fallback: string) {
  if (!error) return fallback;
  if (error.code === "42501" || error.code === "23514") return error.message ?? fallback;
  if (error.code === "23505") return "That email address is already in use.";
  return fallback;
}

export async function createUserAction(input: CreateUserInput): Promise<UserActionResult> {
  // 1. Verify the caller is an active admin (server-side, from the session)
  await requireAdmin();

  const parsed = createUserSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? "Check the form and try again." };
  }
  const data = parsed.data;

  const admin = createAdminClient();
  if (!admin) {
    return {
      ok: false,
      error:
        "User creation isn't configured on the server yet. Add SUPABASE_SECRET_KEY to the server environment and redeploy.",
    };
  }

  // 2. Create the auth account. app_metadata can only be written with the
  //    secret key, so "provisioned" proves an admin created this user.
  const { data: created, error: createError } = await admin.auth.admin.createUser({
    email: data.email,
    password: data.temporaryPassword,
    email_confirm: true,
    user_metadata: { full_name: data.fullName, phone: data.phone },
    app_metadata: { provisioned: true },
  });

  if (createError || !created.user) {
    const msg = createError?.message?.toLowerCase() ?? "";
    if (createError?.code === "email_exists" || msg.includes("already been registered")) {
      return { ok: false, error: "A user with that email already exists." };
    }
    if (createError?.code === "weak_password") {
      return { ok: false, error: "The temporary password is too weak. Use a longer one." };
    }
    return { ok: false, error: "We couldn't create the account. Try again in a moment." };
  }

  const userId = created.user.id;

  // 3. Role, manager and verticals are set with the ADMIN'S OWN session, so
  //    RLS and the guard trigger still check every change.
  const supabase = await createClient();
  const { error: profileError } = await supabase
    .from("profiles")
    .update({
      full_name: data.fullName,
      phone: data.phone,
      role: data.role,
      manager_id: data.managerId,
    })
    .eq("id", userId);

  const { error: verticalError } = profileError
    ? { error: null }
    : await supabase.rpc("admin_set_user_verticals", {
        p_user_id: userId,
        p_vertical_ids: data.verticalIds,
      });

  revalidatePath("/settings/users");

  if (profileError || verticalError) {
    return {
      ok: false,
      error: `Account created, but some details weren't saved: ${dbError(
        profileError ?? verticalError,
        "unknown error",
      )} Open the user to finish setup.`,
    };
  }

  return { ok: true, message: `${data.fullName} can now sign in with the temporary password.`, userId };
}

export async function updateUserAction(input: UpdateUserInput): Promise<UserActionResult> {
  const { profile: actor } = await requireAdmin();

  const parsed = updateUserSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? "Check the form and try again." };
  }
  const data = parsed.data;

  const check = validateAdminChange({
    actorId: actor.id,
    actorRole: actor.role,
    targetId: data.userId,
    nextRole: data.role,
  });
  if (!check.ok) return { ok: false, error: check.reason };

  const supabase = await createClient();
  const { data: updated, error } = await supabase
    .from("profiles")
    .update({
      full_name: data.fullName,
      phone: data.phone,
      role: data.role,
      manager_id: data.managerId,
    })
    .eq("id", data.userId)
    .select("id");

  if (error) return { ok: false, error: dbError(error, "We couldn't save these changes.") };
  if (!updated?.length) return { ok: false, error: "User not found." };

  const { error: vError } = await supabase.rpc("admin_set_user_verticals", {
    p_user_id: data.userId,
    p_vertical_ids: data.verticalIds,
  });
  if (vError) return { ok: false, error: dbError(vError, "We couldn't update vertical access.") };

  revalidatePath("/settings/users");
  revalidatePath(`/settings/users/${data.userId}`);
  return { ok: true, message: "Changes saved." };
}

export async function setUserActiveAction(input: {
  userId: string;
  isActive: boolean;
}): Promise<UserActionResult> {
  const { profile: actor } = await requireAdmin();

  const parsed = setActiveSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: "Invalid request." };
  const { userId, isActive } = parsed.data;

  const check = validateAdminChange({
    actorId: actor.id,
    actorRole: actor.role,
    targetId: userId,
    nextActive: isActive,
  });
  if (!check.ok) return { ok: false, error: check.reason };

  const supabase = await createClient();
  const { data: updated, error } = await supabase
    .from("profiles")
    .update({ is_active: isActive })
    .eq("id", userId)
    .select("id");

  if (error) return { ok: false, error: dbError(error, "We couldn't change this account's status.") };
  if (!updated?.length) return { ok: false, error: "User not found." };

  // Also block / unblock sign-in at the auth level when the server key is set.
  // Data access is already cut off by RLS the moment is_active is false.
  const admin = createAdminClient();
  if (admin) {
    await admin.auth.admin.updateUserById(userId, {
      ban_duration: isActive ? "none" : "876000h",
    });
  }

  revalidatePath("/settings/users");
  revalidatePath(`/settings/users/${userId}`);
  return { ok: true, message: isActive ? "Account activated." : "Account deactivated." };
}
