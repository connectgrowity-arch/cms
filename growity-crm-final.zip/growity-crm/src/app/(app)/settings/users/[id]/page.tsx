import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { z } from "zod";
import { requireAdmin } from "@/lib/auth/session";
import { createClient } from "@/lib/supabase/server";
import { getUserFormOptions } from "@/lib/users/queries";
import { ROLE_LABELS } from "@/lib/permissions";
import { formatDate } from "@/lib/utils/format";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UserForm } from "@/components/forms/user-form";
import { UserStatusToggle } from "@/components/users/user-status-toggle";

export const metadata: Metadata = { title: "User details · Growity CRM" };

export default async function UserDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.guid().safeParse(id).success) notFound();

  const { profile: actor } = await requireAdmin();
  const supabase = await createClient();

  const [{ data: user }, { data: assignments }, options] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", id).maybeSingle(),
    supabase.from("user_verticals").select("vertical_id").eq("user_id", id),
    getUserFormOptions(),
  ]);
  if (!user) notFound();

  const manager = user.manager_id ? options.managers.find((m) => m.id === user.manager_id) : null;
  const isSelf = user.id === actor.id;

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      <Link href="/settings/users" className="inline-flex w-fit items-center gap-1 text-sm text-slate-500 hover:text-slate-900">
        <ArrowLeft className="size-4" aria-hidden /> All users
      </Link>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-semibold tracking-tight">{user.full_name}</h1>
            <Badge variant={user.is_active ? "success" : "muted"}>{user.is_active ? "Active" : "Inactive"}</Badge>
          </div>
          <p className="mt-1 text-sm text-slate-500">
            {user.email} · {ROLE_LABELS[user.role]}
            {manager ? ` · Reports to ${manager.full_name}` : ""}
          </p>
          <p className="mt-0.5 text-xs text-slate-400">
            Added {formatDate(user.created_at)} · Last updated {formatDate(user.updated_at)}
          </p>
        </div>
        <UserStatusToggle userId={user.id} name={user.full_name} isActive={user.is_active} disabled={isSelf} size="default" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Profile and access</CardTitle>
          <CardDescription>Changes are checked by the database before they are saved.</CardDescription>
        </CardHeader>
        <CardContent>
          <UserForm
            mode="edit"
            actorId={actor.id}
            options={options}
            initial={{
              userId: user.id,
              fullName: user.full_name,
              email: user.email,
              phone: user.phone ?? "",
              role: user.role,
              managerId: user.manager_id ?? "",
              verticalIds: (assignments ?? []).map((a) => a.vertical_id),
            }}
          />
        </CardContent>
      </Card>
    </div>
  );
}
