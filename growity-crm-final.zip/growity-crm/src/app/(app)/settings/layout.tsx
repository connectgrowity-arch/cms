import { requireAdmin } from "@/lib/auth/session";

// Every /settings route is admin-only. RLS enforces the same rule in the database.
export default async function SettingsLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin();
  return children;
}
