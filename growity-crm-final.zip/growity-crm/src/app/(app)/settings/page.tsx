import type { Metadata } from "next";
import Link from "next/link";
import { ChevronRight, Users } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert } from "@/components/ui/alert";

export const metadata: Metadata = { title: "Settings · Growity CRM" };

const SETTING_LABELS: Record<string, string> = {
  company_name: "Company name",
  currency: "Currency",
  timezone: "Timezone",
  fiscal_year_start_month: "Fiscal year starts",
};
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

function display(key: string, value: unknown) {
  if (key === "fiscal_year_start_month" && typeof value === "number") return MONTHS[value - 1] ?? String(value);
  return typeof value === "string" ? value : JSON.stringify(value);
}

export default async function SettingsPage() {
  const supabase = await createClient();
  const [{ data: settings, error }, { data: verticals }] = await Promise.all([
    supabase.from("app_settings").select("setting_key, setting_value").order("setting_key"),
    supabase.from("verticals").select("id, code, name, is_active").order("name"),
  ]);

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Settings</h1>
        <p className="mt-1 text-sm text-slate-500">Company configuration for Growity CRM.</p>
      </div>

      <Link href="/settings/users" className="group">
        <Card className="flex items-center gap-3 p-4 transition-colors group-hover:bg-slate-50">
          <span className="rounded-lg bg-brand-50 p-2 text-brand-600"><Users className="size-5" aria-hidden /></span>
          <div className="flex-1">
            <p className="font-medium">Users and access</p>
            <p className="text-sm text-slate-500">Add people, set roles and assign verticals</p>
          </div>
          <ChevronRight className="size-4 text-slate-400" aria-hidden />
        </Card>
      </Link>

      <Card>
        <CardHeader>
          <CardTitle>Company</CardTitle>
          <CardDescription>Stored in the database. Editing arrives in a later phase.</CardDescription>
        </CardHeader>
        <CardContent>
          {error ? (
            <Alert variant="error">We couldn&apos;t load settings.</Alert>
          ) : (
            <dl className="divide-y divide-slate-100">
              {(settings ?? []).map((s) => (
                <div key={s.setting_key} className="flex justify-between gap-4 py-2.5 text-sm">
                  <dt className="text-slate-500">{SETTING_LABELS[s.setting_key] ?? s.setting_key}</dt>
                  <dd className="font-medium text-slate-900">{display(s.setting_key, s.setting_value)}</dd>
                </div>
              ))}
            </dl>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Business verticals</CardTitle>
          <CardDescription>Every lead, customer and opportunity will belong to one of these.</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="divide-y divide-slate-100">
            {(verticals ?? []).map((v) => (
              <li key={v.id} className="flex items-center justify-between py-2.5 text-sm">
                <span className="flex items-center gap-2">
                  <Badge variant="brand">{v.code}</Badge>
                  {v.name}
                </span>
                <Badge variant={v.is_active ? "success" : "muted"}>{v.is_active ? "Active" : "Inactive"}</Badge>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
