import type { Metadata } from "next";
import Link from "next/link";
import {
  UserPlus,
  Sparkles,
  Target,
  IndianRupee,
  PieChart,
  KanbanSquare,
  Activity,
  CalendarClock,
  Rocket,
} from "lucide-react";
import { requireSession } from "@/lib/auth/session";
import { getDashboardMetrics } from "@/lib/dashboard/metrics";
import { ALL_VERTICALS } from "@/lib/verticals/selection";
import { canManageUsers, ROLE_LABELS } from "@/lib/permissions";
import { formatCurrency } from "@/lib/utils/format";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { PlaceholderSection } from "@/components/dashboard/placeholder-section";
import { Alert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = { title: "Dashboard · Growity CRM" };

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ notice?: string; denied?: string }>;
}) {
  const [{ profile, verticals, selectedVertical }, params] = await Promise.all([
    requireSession(),
    searchParams,
  ]);
  const metricsVertical = selectedVertical === ALL_VERTICALS ? null : selectedVertical;
  const metrics = await getDashboardMetrics(metricsVertical);

  const scopeLabel =
    selectedVertical === ALL_VERTICALS
      ? "All verticals"
      : (verticals.find((v) => v.code === selectedVertical)?.name ?? "No vertical assigned");

  return (
    <div className="mx-auto flex max-w-7xl flex-col gap-6">
      {params.notice === "password-updated" && (
        <Alert variant="success">Your password has been updated.</Alert>
      )}
      {params.denied && (
        <Alert variant="error">You don&apos;t have permission to open that page.</Alert>
      )}
      {verticals.length === 0 && (
        <Alert variant="info">
          You haven&apos;t been assigned to a business vertical yet. Ask your admin to add you to
          Growity Agency, Scaler or Growity Academy.
        </Alert>
      )}

      <div className="flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Welcome to Growity CRM</h1>
          <p className="mt-1 text-sm text-slate-500">Manage your customers and grow your business.</p>
        </div>
        <p className="text-sm text-slate-500">
          {profile.full_name} · {ROLE_LABELS[profile.role]} · <span className="font-medium text-slate-700">{scopeLabel}</span>
        </p>
      </div>

      <section aria-label="Key metrics" className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard label="Total Leads" value={String(metrics.totalLeads)} icon={UserPlus} emptyHint="No leads yet" />
        <KpiCard label="New Leads" value={String(metrics.newLeads)} icon={Sparkles} emptyHint="None this month" />
        <KpiCard
          label="Active Opportunities"
          value={String(metrics.activeOpportunities)}
          icon={Target}
          emptyHint="No open opportunities"
        />
        <KpiCard
          label="Won Revenue"
          value={formatCurrency(metrics.wonRevenue)}
          icon={IndianRupee}
          emptyHint="No deals won yet"
        />
      </section>

      {!metrics.hasData && (
        <div className="flex flex-col items-start gap-3 rounded-xl border border-brand-100 bg-brand-50 p-5 sm:flex-row sm:items-center">
          <span className="rounded-lg bg-white p-2 text-brand-600">
            <Rocket className="size-5" aria-hidden />
          </span>
          <p className="flex-1 text-sm text-brand-700">
            Your CRM is ready. Start by adding your first lead in the next phase.
          </p>
          {canManageUsers(profile.role) && (
            <Button asChild variant="outline" size="sm">
              <Link href="/settings/users">Set up your team</Link>
            </Button>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <PlaceholderSection
          title="Lead Overview"
          description="Lead volume by source and status"
          icon={PieChart}
          emptyTitle="No lead data yet"
          emptyDescription="Lead charts will appear here once lead management is live."
        />
        <PlaceholderSection
          title="Sales Pipeline"
          description="Opportunities by stage"
          icon={KanbanSquare}
          emptyTitle="No pipeline yet"
          emptyDescription="Your pipeline stages and values will show here."
        />
        <PlaceholderSection
          title="Recent Activities"
          description="Calls, meetings and notes"
          icon={Activity}
          emptyTitle="No activity yet"
          emptyDescription="Your team's latest activity will be listed here."
        />
        <PlaceholderSection
          title="Upcoming Follow-ups"
          description="What's due next"
          icon={CalendarClock}
          emptyTitle="Nothing scheduled"
          emptyDescription="Follow-ups you schedule will appear here."
        />
      </div>
    </div>
  );
}
