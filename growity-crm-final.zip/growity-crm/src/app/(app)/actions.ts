"use server";

import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";
import { getSessionContext } from "@/lib/auth/session";
import { VERTICAL_COOKIE, isValidSelection } from "@/lib/verticals/selection";

/** Remember the chosen vertical. Validated against what RLS lets this user see. */
export async function setVerticalAction(value: string) {
  const ctx = await getSessionContext();
  if (!ctx) return { ok: false as const, error: "Your session has ended. Sign in again." };
  if (!isValidSelection(value, ctx.profile.role, ctx.verticals)) {
    return { ok: false as const, error: "You don't have access to that vertical." };
  }
  const cookieStore = await cookies();
  cookieStore.set(VERTICAL_COOKIE, value, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 365,
  });
  revalidatePath("/", "layout");
  return { ok: true as const };
}
