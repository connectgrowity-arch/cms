import { AppShell } from "@/components/layout/app-shell";
import { requireSession } from "@/lib/auth/session";
import { canSelectAllVerticals } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const { profile, verticals, selectedVertical } = await requireSession();

  return (
    <AppShell
      user={{ name: profile.full_name, email: profile.email, role: profile.role }}
      vertical={{
        verticals,
        selected: selectedVertical,
        canSelectAll: canSelectAllVerticals(profile.role),
      }}
    >
      {children}
    </AppShell>
  );
}
