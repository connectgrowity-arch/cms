import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";

async function signOut(request: NextRequest) {
  const supabase = await createClient();
  await supabase.auth.signOut();
  const reason = request.nextUrl.searchParams.get("reason");
  const url = new URL("/login", request.nextUrl.origin);
  url.searchParams.set("notice", reason === "inactive" ? "inactive" : "signed-out");
  return NextResponse.redirect(url, { status: 303 });
}

export const POST = signOut;
// GET is used only for the forced sign-out of deactivated accounts
export const GET = signOut;
