"use client";

import { createContext } from "react";
import type { VerticalOption } from "@/lib/verticals/selection";

export type VerticalContextValue = {
  verticals: VerticalOption[];
  selected: string | null; // vertical code, "ALL", or null when none assigned
  canSelectAll: boolean;
};

export const VerticalContext = createContext<VerticalContextValue | null>(null);

export function VerticalProvider({
  value,
  children,
}: {
  value: VerticalContextValue;
  children: React.ReactNode;
}) {
  return <VerticalContext.Provider value={value}>{children}</VerticalContext.Provider>;
}
