import { cn } from "@/lib/utils/cn";

export function BrandMark({ className, compact }: { className?: string; compact?: boolean }) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <span
        aria-hidden
        className="flex size-8 items-center justify-center rounded-lg bg-brand-600 text-sm font-bold text-white"
      >
        G
      </span>
      {!compact && (
        <span className="text-base font-semibold tracking-tight text-slate-900">
          Growity <span className="font-normal text-slate-500">CRM</span>
        </span>
      )}
    </div>
  );
}
