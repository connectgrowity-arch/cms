"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { Bell, Menu, Search, X } from "lucide-react";
import { BrandMark } from "./brand-mark";
import { VerticalProvider, type VerticalContextValue } from "./vertical-context";
import { SidebarNav } from "@/components/navigation/sidebar-nav";
import { VerticalSelector } from "@/components/navigation/vertical-selector";
import { UserMenu } from "@/components/navigation/user-menu";
import { Button } from "@/components/ui/button";
import type { AppRole } from "@/types/database";

type ShellUser = { name: string; email: string; role: AppRole };

export function AppShell({
  user,
  vertical,
  children,
}: {
  user: ShellUser;
  vertical: VerticalContextValue;
  children: React.ReactNode;
}) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => setMobileOpen(false), [pathname]);

  useEffect(() => {
    if (!mobileOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setMobileOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [mobileOpen]);

  return (
    <VerticalProvider value={vertical}>
      <div className="flex min-h-dvh">
        {/* Desktop sidebar */}
        <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-slate-200 bg-slate-50 lg:flex">
          <div className="flex h-16 items-center border-b border-slate-200 px-5">
            <BrandMark />
          </div>
          <div className="flex-1 overflow-y-auto px-3 py-5">
            <SidebarNav role={user.role} />
          </div>
        </aside>

        {/* Mobile drawer */}
        {mobileOpen && (
          <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation">
            <div className="absolute inset-0 bg-slate-900/40" onClick={() => setMobileOpen(false)} />
            <aside className="absolute inset-y-0 left-0 flex w-72 max-w-[85vw] flex-col bg-slate-50 shadow-xl">
              <div className="flex h-16 items-center justify-between border-b border-slate-200 px-5">
                <BrandMark />
                <Button variant="ghost" size="icon-sm" onClick={() => setMobileOpen(false)} aria-label="Close navigation">
                  <X />
                </Button>
              </div>
              <div className="flex-1 overflow-y-auto px-3 py-5">
                <SidebarNav role={user.role} onNavigate={() => setMobileOpen(false)} />
              </div>
            </aside>
          </div>
        )}

        <div className="flex min-w-0 flex-1 flex-col lg:pl-64">
          <header className="sticky top-0 z-20 flex h-16 items-center gap-2 border-b border-slate-200 bg-white/95 px-3 backdrop-blur sm:gap-3 sm:px-6">
            <Button
              variant="ghost"
              size="icon-sm"
              className="lg:hidden"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation"
            >
              <Menu />
            </Button>
            <BrandMark compact className="lg:hidden" />

            <VerticalSelector />

            <div className="relative ml-auto hidden max-w-xs flex-1 md:block">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" aria-hidden />
              <input
                type="search"
                disabled
                placeholder="Search (coming soon)"
                aria-label="Search, coming soon"
                className="h-9 w-full cursor-not-allowed rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-sm placeholder:text-slate-400"
              />
            </div>

            <div className="ml-auto flex items-center gap-1 md:ml-0">
              <Button
                variant="ghost"
                size="icon-sm"
                disabled
                aria-label="Notifications (coming soon)"
                title="Notifications (coming soon)"
              >
                <Bell />
              </Button>
              <UserMenu name={user.name} email={user.email} role={user.role} />
            </div>
          </header>

          <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">{children}</main>
        </div>
      </div>
    </VerticalProvider>
  );
}
