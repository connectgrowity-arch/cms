import type { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";

/**
 * KPI tile. `value` is null until the module that produces it exists, so the
 * card shows a clear empty state rather than an invented number.
 */
export function KpiCard({
  label,
  value,
  icon: Icon,
  emptyHint,
}: {
  label: string;
  value: string | null;
  icon: LucideIcon;
  emptyHint: string;
}) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-slate-500">{label}</p>
        <span className="rounded-lg bg-slate-100 p-2 text-slate-500">
          <Icon className="size-4" aria-hidden />
        </span>
      </div>
      <p className="mt-3 text-2xl font-semibold tabular-nums text-slate-900">{value ?? "0"}</p>
      <p className="mt-1 text-xs text-slate-500">{emptyHint}</p>
    </Card>
  );
}
