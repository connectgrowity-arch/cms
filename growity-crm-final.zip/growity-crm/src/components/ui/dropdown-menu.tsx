"use client";
import * as React from "react";
import * as Dm from "@radix-ui/react-dropdown-menu";
import { cn } from "@/lib/utils/cn";

export const DropdownMenu = Dm.Root;
export const DropdownMenuTrigger = Dm.Trigger;

export function DropdownMenuContent({
  className,
  ...props
}: React.ComponentPropsWithoutRef<typeof Dm.Content>) {
  return (
    <Dm.Portal>
      <Dm.Content
        sideOffset={6}
        align="end"
        className={cn(
          "z-50 min-w-48 rounded-xl border border-slate-200 bg-white p-1 shadow-md",
          className,
        )}
        {...props}
      />
    </Dm.Portal>
  );
}

export function DropdownMenuItem({
  className,
  ...props
}: React.ComponentPropsWithoutRef<typeof Dm.Item>) {
  return (
    <Dm.Item
      className={cn(
        "flex cursor-pointer select-none items-center gap-2 rounded-lg px-2.5 py-2 text-sm text-slate-700 outline-none data-[highlighted]:bg-slate-100 [&_svg]:size-4",
        className,
      )}
      {...props}
    />
  );
}

export const DropdownMenuSeparator = () => <Dm.Separator className="my-1 h-px bg-slate-100" />;
export const DropdownMenuLabel = ({ children }: { children: React.ReactNode }) => (
  <Dm.Label className="px-2.5 py-2">{children}</Dm.Label>
);
