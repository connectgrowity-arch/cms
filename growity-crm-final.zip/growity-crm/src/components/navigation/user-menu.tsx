"use client";

import { LogOut, ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ROLE_LABELS } from "@/lib/permissions";
import { initials } from "@/lib/utils/format";
import type { AppRole } from "@/types/database";

export function UserMenu({ name, email, role }: { name: string; email: string; role: AppRole }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        className="flex items-center gap-2 rounded-lg p-1 pr-2 hover:bg-slate-100"
        aria-label="Open user menu"
      >
        <span className="flex size-8 items-center justify-center rounded-full bg-brand-50 text-xs font-semibold text-brand-700">
          {initials(name)}
        </span>
        <span className="hidden flex-col items-start text-left leading-tight md:flex">
          <span className="text-sm font-medium text-slate-900">{name}</span>
          <span className="text-xs text-slate-500">{ROLE_LABELS[role]}</span>
        </span>
        <ChevronDown className="hidden size-4 text-slate-400 md:block" aria-hidden />
      </DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuLabel>
          <p className="text-sm font-medium text-slate-900">{name}</p>
          <p className="truncate text-xs text-slate-500">{email}</p>
          <p className="mt-1 text-xs font-medium text-brand-700">{ROLE_LABELS[role]}</p>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <form action="/auth/signout" method="post">
          <DropdownMenuItem asChild>
            <button type="submit" className="w-full text-red-600">
              <LogOut aria-hidden />
              Sign out
            </button>
          </DropdownMenuItem>
        </form>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
