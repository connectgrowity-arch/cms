"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Layers, Loader2 } from "lucide-react";
import { setVerticalAction } from "@/app/(app)/actions";
import { useVertical } from "@/hooks/use-vertical";
import { ALL_VERTICALS } from "@/lib/verticals/selection";

export function VerticalSelector() {
  const { verticals, selected, canSelectAll } = useVertical();
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  if (verticals.length === 0) {
    return (
      <span className="rounded-lg border border-dashed border-slate-200 px-3 py-1.5 text-xs text-slate-500">
        No vertical assigned
      </span>
    );
  }

  return (
    <label className="relative flex items-center">
      <span className="sr-only">Business vertical</span>
      {pending ? (
        <Loader2 className="pointer-events-none absolute left-2.5 size-4 animate-spin text-slate-400" aria-hidden />
      ) : (
        <Layers className="pointer-events-none absolute left-2.5 size-4 text-slate-400" aria-hidden />
      )}
      <select
        value={selected ?? ""}
        disabled={pending}
        onChange={(e) => {
          const value = e.target.value;
          startTransition(async () => {
            const r = await setVerticalAction(value);
            if (r.ok) router.refresh();
          });
        }}
        className="h-9 max-w-[11rem] appearance-none truncate rounded-lg border border-slate-200 bg-white pl-8 pr-3 text-sm font-medium text-slate-700 hover:bg-slate-50 sm:max-w-none"
      >
        {canSelectAll && <option value={ALL_VERTICALS}>All Verticals</option>}
        {verticals.map((v) => (
          <option key={v.id} value={v.code}>
            {v.name}
          </option>
        ))}
      </select>
    </label>
  );
}
