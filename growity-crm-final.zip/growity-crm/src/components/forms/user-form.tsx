"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { createUserAction, updateUserAction } from "@/app/(app)/settings/users/actions";
import { createUserSchema, updateUserSchema } from "@/lib/validations/users";
import { ROLES, ROLE_LABELS } from "@/lib/permissions";
import type { UserFormOptions } from "@/lib/users/queries";
import type { AppRole } from "@/types/database";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NativeSelect } from "@/components/ui/native-select";
import { Field } from "@/components/ui/field";
import { Alert } from "@/components/ui/alert";

type FormValues = {
  userId?: string;
  fullName: string;
  email: string;
  phone: string;
  role: AppRole;
  managerId: string;
  verticalIds: string[];
  temporaryPassword: string;
};

type Props = {
  mode: "create" | "edit";
  options: UserFormOptions;
  initial?: Partial<FormValues> & { userId: string };
  /** The signed-in admin's id, so we can lock their own role */
  actorId: string;
  onDone?: () => void;
};

export function UserForm({ mode, options, initial, actorId, onDone }: Props) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [result, setResult] = useState<{ ok: boolean; text: string } | null>(null);
  const isSelf = mode === "edit" && initial?.userId === actorId;

  const schema = mode === "create" ? createUserSchema : updateUserSchema;
  const {
    register,
    handleSubmit,
    getValues,
    formState: { errors, isDirty },
  } = useForm<FormValues>({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resolver: zodResolver(schema as any) as any,
    mode: "onTouched",
    defaultValues: {
      userId: initial?.userId,
      fullName: initial?.fullName ?? "",
      email: initial?.email ?? "",
      phone: initial?.phone ?? "",
      role: initial?.role ?? "salesperson",
      managerId: initial?.managerId ?? "",
      verticalIds: initial?.verticalIds ?? [],
      temporaryPassword: "",
    },
  });

  const managers = options.managers.filter((m) => m.id !== initial?.userId);

  const onSubmit = handleSubmit(() => {
    setResult(null);
    const v = getValues();
    startTransition(async () => {
      const r =
        mode === "create"
          ? await createUserAction({
              fullName: v.fullName,
              email: v.email,
              phone: v.phone,
              role: v.role,
              managerId: v.managerId,
              verticalIds: v.verticalIds,
              temporaryPassword: v.temporaryPassword,
            })
          : await updateUserAction({
              userId: v.userId!,
              fullName: v.fullName,
              phone: v.phone,
              role: v.role,
              managerId: v.managerId,
              verticalIds: v.verticalIds,
            });

      setResult(r.ok ? { ok: true, text: r.message } : { ok: false, text: r.error });
      if (r.ok) {
        router.refresh();
        if (mode === "create") onDone?.();
      }
    });
  });

  return (
    <form onSubmit={onSubmit} noValidate className="flex flex-col gap-4">
      {result && <Alert variant={result.ok ? "success" : "error"}>{result.text}</Alert>}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field id="fullName" label="Full name" error={errors.fullName?.message}>
          <Input id="fullName" autoComplete="off" aria-invalid={!!errors.fullName} {...register("fullName")} />
        </Field>

        <Field
          id="email"
          label="Email"
          error={errors.email?.message}
          hint={mode === "edit" ? "Email changes are handled in Supabase Auth." : undefined}
        >
          <Input
            id="email"
            type="email"
            autoComplete="off"
            disabled={mode === "edit"}
            aria-invalid={!!errors.email}
            {...register("email")}
          />
        </Field>

        <Field id="phone" label="Phone (optional)" error={errors.phone?.message}>
          <Input id="phone" type="tel" inputMode="tel" placeholder="+91 98765 43210" {...register("phone")} />
        </Field>

        <Field
          id="role"
          label="Role"
          error={errors.role?.message}
          hint={isSelf ? "You can't change your own role." : undefined}
        >
          <NativeSelect id="role" disabled={isSelf} {...register("role")}>
            {ROLES.map((r) => (
              <option key={r} value={r}>
                {ROLE_LABELS[r]}
              </option>
            ))}
          </NativeSelect>
        </Field>

        <Field id="managerId" label="Reports to" error={errors.managerId?.message}>
          <NativeSelect id="managerId" {...register("managerId")}>
            <option value="">No manager</option>
            {managers.map((m) => (
              <option key={m.id} value={m.id}>
                {m.full_name} · {ROLE_LABELS[m.role]}
              </option>
            ))}
          </NativeSelect>
        </Field>

        {mode === "create" && (
          <Field
            id="temporaryPassword"
            label="Temporary password"
            error={errors.temporaryPassword?.message}
            hint="Share it privately. They can change it with “Forgot password”."
          >
            <Input
              id="temporaryPassword"
              type="text"
              autoComplete="new-password"
              aria-invalid={!!errors.temporaryPassword}
              {...register("temporaryPassword")}
            />
          </Field>
        )}
      </div>

      <fieldset className="flex flex-col gap-2">
        <legend className="mb-1 text-sm font-medium text-slate-700">Verticals</legend>
        <p className="-mt-1 text-xs text-slate-500">
          Admins and CXOs see every vertical regardless of these assignments.
        </p>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
          {options.verticals.map((v) => (
            <label
              key={v.id}
              className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-3 py-2.5 text-sm hover:bg-slate-50 has-[:checked]:border-brand-500 has-[:checked]:bg-brand-50"
            >
              <input type="checkbox" value={v.id} className="size-4 accent-brand-600" {...register("verticalIds")} />
              <span>{v.name}</span>
              <span className="ml-auto text-xs text-slate-400">{v.code}</span>
            </label>
          ))}
        </div>
      </fieldset>

      <div className="flex justify-end gap-2 pt-2">
        <Button type="submit" loading={pending} disabled={mode === "edit" && !isDirty}>
          {mode === "create" ? "Create user" : "Save changes"}
        </Button>
      </div>
    </form>
  );
}
