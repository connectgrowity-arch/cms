"use client";

import { useState } from "react";
import { UserPlus } from "lucide-react";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { UserForm } from "@/components/forms/user-form";
import type { UserFormOptions } from "@/lib/users/queries";

export function AddUserDialog({ options, actorId }: { options: UserFormOptions; actorId: string }) {
  const [open, setOpen] = useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <UserPlus aria-hidden />
          Add user
        </Button>
      </DialogTrigger>
      <DialogContent
        title="Add user"
        description="Creates a sign-in for a team member. Public sign-up is disabled."
        className="sm:max-w-2xl"
      >
        <UserForm mode="create" options={options} actorId={actorId} onDone={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}
