"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent } from "@/components/ui/dialog";
import { Alert } from "@/components/ui/alert";
import { setUserActiveAction } from "@/app/(app)/settings/users/actions";

export function UserStatusToggle({
  userId,
  name,
  isActive,
  disabled,
  size = "sm",
}: {
  userId: string;
  name: string;
  isActive: boolean;
  disabled?: boolean;
  size?: "sm" | "default";
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  function apply() {
    setError(null);
    startTransition(async () => {
      const r = await setUserActiveAction({ userId, isActive: !isActive });
      if (!r.ok) {
        setError(r.error);
        return;
      }
      setOpen(false);
      router.refresh();
    });
  }

  return (
    <>
      <Button
        variant="outline"
        size={size}
        disabled={disabled}
        title={disabled ? "You can't deactivate your own account" : undefined}
        onClick={() => (isActive ? setOpen(true) : apply())}
        loading={pending && !open}
      >
        {isActive ? "Deactivate" : "Activate"}
      </Button>
      {error && !open && (
        <span role="alert" className="text-xs text-red-600">
          {error}
        </span>
      )}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent
          title={`Deactivate ${name}?`}
          description="They'll be signed out and lose access to all CRM data immediately. Their records stay in place, and you can reactivate them at any time."
        >
          {error && <Alert variant="error" className="mb-4">{error}</Alert>}
          <div className="flex justify-end gap-2">
            <DialogClose asChild>
              <Button variant="outline">Keep active</Button>
            </DialogClose>
            <Button variant="destructive" onClick={apply} loading={pending}>
              Deactivate {name.split(" ")[0]}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
