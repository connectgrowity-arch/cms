// Fails if a server-only secret leaks into the browser bundle.
// Run after `next build`:  npm run check:secrets
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";

const root = ".next/static";
const secret = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;
const patterns = [/sb_secret_[A-Za-z0-9_-]{10,}/, /SUPABASE_SECRET_KEY/, /SUPABASE_SERVICE_ROLE_KEY/, /"role"\s*:\s*"service_role"/];

function walk(dir) {
  return readdirSync(dir).flatMap((f) => {
    const p = join(dir, f);
    return statSync(p).isDirectory() ? walk(p) : [p];
  });
}

let files;
try {
  files = walk(root).filter((f) => /\.(js|css|html|json|map)$/.test(f));
} catch {
  console.error("No .next/static folder. Run `npm run build` first.");
  process.exit(1);
}

const leaks = [];
for (const f of files) {
  const text = readFileSync(f, "utf8");
  if (secret && text.includes(secret)) leaks.push(`${f}: contains the secret key value`);
  for (const p of patterns) if (p.test(text)) leaks.push(`${f}: matches ${p}`);
}

if (leaks.length) {
  console.error("Secret leak check FAILED:\n" + leaks.join("\n"));
  process.exit(1);
}
console.log(`Secret leak check passed (${files.length} client files scanned).`);
